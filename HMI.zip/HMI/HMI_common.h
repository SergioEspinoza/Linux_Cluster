/******************************************************************************/
/*!
 *  \file		HMI_common.h
 *
 *  \copyright	Yazaki 2017
 *
 *  \brief		Common GP HMI application definitions.
 *
 *  \author		D. Kageff
 *
 *  \version	$Revision: 1.1 $ 
 *				$Log: HMI_common.h  $
 *				Revision 1.1 2017/02/16 17:20:25CST Daniel Kageff (10011932) 
 *				Initial revision
 *				Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/project.pj
 *
 *
 ***************************************************************************************/
#ifndef _HMI_COMMON_H
#define _HMI_COMMON_H

/***********************************
	Public Macros and Typedefs
***********************************/

#define HMI_FRAME_TIME 17				/*!< Frame period - currently 17 msec. */

#define IMAGE_FILE_EXT		"png"		/*!< Extension for audio window image files */

/* HMI options configuration key bitmask values */
#define HMI_OPT_NORMAL		0x00000001		/*!< Normal operating mode */
#define HMI_OPT_DEMO1		0x00000002		/*!< Display single demo screen */
#define HMI_OPT_SIM			0x00000004		/*!< Display 'canned' demo screens */
#define HMI_OPT_SIM_BLNK	0x0000000c		/*!< For 'canned' demo screens, blank display between loops */


#endif
