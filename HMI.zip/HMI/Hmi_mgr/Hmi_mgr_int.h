#define Hm_Clk	ClockObjectNumber(10U)
#define Hm_DplTsk	TaskObjectNumber(11U)
#define Hm_DplClk	ClockObjectNumber(12U)
