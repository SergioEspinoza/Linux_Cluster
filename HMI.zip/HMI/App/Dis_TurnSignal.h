/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/

/**************************************************************************************/
/*!
*    \file    	Dis_TurnSignal.h
*
*    \copyright Yazaki 2016
*
*    \brief 	Header file containing the public interfaces and data for the Gear position
*
*    \author   Fernando Villarreal
*
*    Modification history:
*    $Log: Dis_TurnSignal.h  $
*    Revision 1.1 2016/09/13 14:01:04CDT Daniel Kageff (10011932) 
*    Initial revision
*    Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/App/project.pj
*
*/
/***************************************************************************************/

#ifndef DIS_TURNSIGNAL_H
#define DIS_TURNSIGNAL_H

/***********************************
		   INCLUDE FILES
***********************************/
#include "datainterface.h"
/***********************************
	Public Macros and Typedefs
***********************************/
enum TurnSigState
{
    TurnSig_OFF = 0,
    TurnSig_ON,
    TurnSig_Fault
};
/***********************************
	Public Data and Structures
***********************************/
 
 
/**********************************************************
               Public Function Prototypes
   (Instrumented function headers are in the .c file)
***********************************************************/


/**************************************************************************************/
/*! \fn GearPosition_StartupInit ( void )
*
*
*  \par Description:
*  This function is called at the startup of the HMI and initialize the state of the Gear state
*
**************************************************************************************/
 
void TurnSignal_StartupInit(void);

/**************************************************************************************/
/*! \fn GearPosition_PeriodicTask ( void )
*
*
*  \par Description:
*  
*
**************************************************************************************/
 
 void TurnSignal_PeriodicTask(void);
 
 
 #endif
 /* End of file */
