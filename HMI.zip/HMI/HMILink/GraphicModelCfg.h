/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/**************************************************************************************/
/*!
 *    \file    	GraphicModelCfg.h
 *
 *    \copyright Yazaki 2016
 *
 *    \brief 	Header file containing the public interfaces and data for the TBD
 *				software component.
 *
 *    \author   Fernando V.
 *
 *  Modification history:
 *   $Log: GraphicModelCfg.h  $
 *   Revision 1.4 2016/12/12 14:49:10CST Fernando Villarreal Garza (10011234) 
 *   changed animation to used 30ms step and update FF logo animation
 *   Revision 1.3 2016/12/08 10:30:39CST Fernando Villarreal Garza (10011234) 
 *   Added animations for the white lanes during blinking 
 *   added defines for the magic numbers and animations names used
 *   Revision 1.2 2016/12/06 10:54:57CST Fernando Villarreal Garza (10011234) 
 *   changes for HMI 2Version
 *   Revision 1.1 2016/10/06 14:57:24EDT Fernando Villarreal Garza (10011234) 
 *   Initial revision
 *   Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/HMILink/project.pj
 *
 */
/***************************************************************************************/

#ifndef GRAPHICMODELCFG_H
#define GRAPHICMODELCFG_H
#include "altia.h"

#define MODE_SCREEN_ANIM_NAME  ALT_TEXT("mode_card")
#define MODE_SCREEN_FF_LOGO         (0)
#define MODE_SCREEN_MAIN_SCREEN     (2)
#define MODE_SCREEN_TEST_PATTERN    (4)

//Opening Animations
#define OPENING_ANIM_NAME   ALT_TEXT("ff_logo_animation_card")
#define OPENING_ANIM_INIT   120

/*
 *  General animations for Main screen 
*/

//Miles Remaining Bar animtion
#define MILES_REMAIN_BAR_AIM        ALT_TEXT("mi_bar_animation")


//Range Readout 
#define RANGE_VALUE_ANIM            ALT_TEXT("range_readout")
#define RANGE_UNIT_TXT_COLOR        ALT_TEXT("bottom_mi_dim")
 
 //Turn Signal
#define TURN_SIG_ENABLE              (1)
#define TURN_SIG_DISABLE             (0)

#define TURN_SIG_SELECT                     ALT_TEXT("Turn_Signal_Enable")
 //Turn Left Green
#define TURN_LEFT_GREEN_LANE_ANIM_NAME      ALT_TEXT("left_green_lane_visible") 
#define TURN_LEFT_GREEN_ANIM_NAME           ALT_TEXT("left_green_turn_visible") 
//Turn Right Green
#define TURN_RIGHT_GREEN_LANE_ANIM_NAME     ALT_TEXT("right_green_lane_visible")
#define TURN_RIGHT_GREEN_ANIM_NAME          ALT_TEXT("right_green_turn_visible")
// Turn left Red 
#define TURN_LEFT_RED_LANE_ANIM_NAME        ALT_TEXT("left_red_lane_visible")
#define TURN_LEFT_RED_ANIM_NAME             ALT_TEXT("left_red_turn_visible")
// Turn Right Red 
#define TURN_RIGHT_RED_LANE_ANIM_NAME       ALT_TEXT("right_red_lane_visible")
#define TURN_RIGHT_RED_ANIM_NAME            ALT_TEXT("right_red_turn_visible")
//White lane
#define TURN_WHITE_LANE_RIGHT_ENABLE        ALT_TEXT("white_lane_right_visible")
#define TURN_WHITE_LANE_LEFT_ENABLE         ALT_TEXT("white_lane_left_visible")
  
//PRNDL
#define PRNDL_VALUE_ANIM_NAME          ALT_TEXT("prndl_card")
#define PRNDL_VALUE_MAX                3
 
//Speed
#define SPEED_VALUE_ANIM_NAME       ALT_TEXT("speed_readout_text")

//Test Pattern 
#define TEST_PATTERN_VALUE          ALT_TEXT("test_pattern_card")


//Dynamic Motor Power Bar 
#define DYNAMIC_POWER_BAR           ALT_TEXT("pwr_bar_animation")
#define DYNAMIC_POWER_BAR_MAX       (100)
#define DYNAMIC_ECO_BAR             ALT_TEXT("eco_bar_animation")
#define DYNAMIC_ECO_BAR_MAX         (50)
#define DYNAMIC_CHG_BAR             ALT_TEXT("chg_bar_animation")
#define DYNAMIC_CHG_BAR_MAX         (50)

//Dyanmic Motor Power Text label 
#define DYNAMIC_MOTOR_TXT_WHITE     (0)
#define DYNAMIC_MOTOR_TXT_GRAY      (1)

#define DYNAMIC_POWER_TXT_COLOR        ALT_TEXT("bottom_pwr_dim")
#define DYNAMIC_CHG_TXT_COLOR          ALT_TEXT("bottom_chg_dim")
#define DYNAMIC_ECO_TXT_COLOR          ALT_TEXT("bottom_eco_dim")


//Speed Limit information
#define SPEED_LIMIT_INFO_ANIM       ALT_TEXT("speed_limit_sign_card")
#define SPEED_LIMIT_INFO_ENABLE     (0)
#define SPEED_LIMIT_INFO_DISABLE    (-1)

//Cruise Control 
#define ACC_ANIM_NAME               ALT_TEXT("ACC_visible")
#define ACC_ANIM_ENABLE             (1)
#define ACC_ANIM_DISABLE            (0)

//Drive mode selection
#define DRIVE_MODE_SELECT_ANIM      ALT_TEXT("drive_mode_card")
#define DRIVE_MODE_DISABLE          (-1)
#define DRIVE_MODE_SPORT            (0)

#endif