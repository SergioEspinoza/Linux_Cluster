/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/********************************************************************************************
*  File:  hmi_callbacks.c
*
*  Description: This file contains the callback functions the HMI Model invokes to interact
*     with the system.
*
********************************************************************************************/
#define HMI_CALLBACKS_C

/*******************************************************************************************/
/*    I N C L U D E   F I L E S                                                            */
/*******************************************************************************************/
#include "hmi_ss.h"
#include "hmi_priv.h"
#include "hmi_callbacks.h"
#include "HMIControlSystemConstants.h"
#include "HMIControlSystemSEMTypes.h"
#include "datainterface.h"

/*******************************************************************************************/
/*    M A C R O S                                                                          */
/*******************************************************************************************/

/*******************************************************************************************/
/*    T Y P E S   A N D   E N U M E R A T I O N S                                          */
/*******************************************************************************************/

/*******************************************************************************************/
/*    F U N C T I O N   P R O T O T Y P E S                                                */
/*******************************************************************************************/


/*******************************************************************************************/
/*    M E M O R Y   A L L O C A T I O N                                                    */
/*******************************************************************************************/




/********************************************************************************************
*  Function Name: Dummy_Callback
*
*  Description:  Dummy callback function for integration and test.
*
*  Input(s):    None.
*
*  Outputs(s):  None.
*
*  Returns:     None.
*
*  Change History:
*       02/24/2013     First version (Greg Palarski)
********************************************************************************************/
void Dummy_Callback(void)
{
}




/* End of file */

