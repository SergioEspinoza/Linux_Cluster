/*
 * Id:        HMIControlSystemData.c
 *
 * Function:  VS System Data Source File.
 *
 * This is an automatically generated file. It will be overwritten by the Coder.
 * 
 * DO NOT EDIT THE FILE!
 */


#include "HMIControlSystemSEMLibB.h"


#if (VS_CODER_GUID != 0X00bffeeecL)
#error The generated file does not match the SEMTypes.h header file.
#endif


#include "HMIControlSystemData.h"


#include "HMIControlSystemConstants.h"


#include "HMIControlSystemAction.h"


#include <stdarg.h>


/*
 * VS System External Variable Definitions.
 */
int BuildUpComplete = 0;

int OpeningAnimComplete = 0;


/*
 * Guard Expression Functions.
 */

static _Bool HMIControlSystemVSGuard_0 (void);
static _Bool HMIControlSystemVSGuard_0 (void)
{
  return (_Bool)(OpeningAnimComplete == 1);
}

static _Bool HMIControlSystemVSGuard_1 (void);
static _Bool HMIControlSystemVSGuard_1 (void)
{
  return (_Bool)(OpeningAnimComplete != 1);
}

static _Bool HMIControlSystemVSGuard_2 (void);
static _Bool HMIControlSystemVSGuard_2 (void)
{
  return (_Bool)(BuildUpComplete == 1);
}

static _Bool HMIControlSystemVSGuard_3 (void);
static _Bool HMIControlSystemVSGuard_3 (void)
{
  return (_Bool)(BuildUpComplete != 1);
}


/*
 * Guard Expression Pointer Table.
 */
VS_GUARDEXPR_TYPE const HMIControlSystemVSGuard[4] = 
{
  HMIControlSystemVSGuard_0,
  HMIControlSystemVSGuard_1,
  HMIControlSystemVSGuard_2,
  HMIControlSystemVSGuard_3
};


/*
 * Action Expression Functions.
 */
void System1VSAction_2 (void)
{
  DisplayManagerSetScreen(FF_LOGO_STATE);
}
void System1VSAction_3 (void)
{
  DisplayManagerSetScreen(TEST_PATTERN_STATE);
}
void System1VSAction_4 (void)
{
  DisplayManagerRefreshScreen(TEST_PATTERN_STATE);
}
void System1VSAction_5 (void)
{
  DisplayManagerSetScreen(FF_BUILDUP_STATE);
}
void System1VSAction_6 (void)
{
  DisplayManagerRefreshScreen(FF_LOGO_STATE);
}
void System1VSAction_7 (void)
{
  DisplayManagerSetScreen(FF_MAIN_STATE);
}
void System1VSAction_8 (void)
{
  DisplayManagerRefreshScreen(FF_BUILDUP_STATE);
}
void System1VSAction_9 (void)
{
  DisplayManagerRefreshScreen(FF_MAIN_STATE);
}


/*
 * Action Expression Pointer Table.
 */
VS_ACTIONEXPR_TYPE const System1VSAction[10] = 
{
  DisplayManagerInit,
  (VS_ACTIONEXPR_TYPE) NULL /* declared action function is never used */,
  System1VSAction_2,
  System1VSAction_3,
  System1VSAction_4,
  System1VSAction_5,
  System1VSAction_6,
  System1VSAction_7,
  System1VSAction_8,
  System1VSAction_9
};
