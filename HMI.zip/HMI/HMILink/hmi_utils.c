/******************************************************************
 * df.c
 *
 *  Description: 
 *   Created on: Jun 4, 2014
 *       Author: 10012885
 ******************************************************************/
#ifndef HMI_UTILS_C_
#define HMI_UTILS_C_
#endif

/* Included Headers */
#include "hmi_utils.h"
#include <math.h>

/* Module Configuration */

/* Other Constant Declaration */

/* Global Variable Declarations */
void flipstr(char *str, int len);
/* Local Function Prototypes */
void flipstr(char *str, int len) {
	int i=0,j=len-1, temp;
	while (i<j){
		temp = str[i];
		str[i] = str[j];
		str[j] = temp;
		i++; j--;
	}
}
/*
int Integer_Str(int value, char * str, int decimal_zero) {
	int icounter = 0;
	int tmp_val=value;
	int tcnter=0;
	while (tmp_val){
		tmp_val =tmp_val/10; tcnter++;
	}
	while (value){
		str[icounter++] = (value%10) + '0';
		value =value/10;
		if(decimal_zero==icounter){
			str[icounter++] ='.';
		}
	}
	flipstr(str,icounter);
	str[icounter] = '\0';
	return icounter;
}
minus_flag
*/

uint32_t SpeedConvertUnit(uint32_t SpeedValue, uint8_t Speedunit)
{
	uint32_t SpeedValueRet = 0;
	SpeedValueRet = (uint32_t)(SpeedValue*50/80);
	return SpeedValueRet;
}


/******************************************************************************************
*  
*	Function	: Integer_Str(int value, char * dest_ptr, int decimal_zero,int len_str)
*	value		: Input integer value.
*	dest_ptr	: Pointer to the destination array where the content is 
*			  	  to be copied, type-casted to a pointer of type char *
*   decimal_zero: Decimal dot position.
*	len_str		: Max String len to be copied
*	Returns 	: String size ||  0 if error ocurred.
*	Autor: E.Sanchez	
*********************************************************************************************/
int Integer_Str(int value, char * dest_ptr, int decimal_zero,int len_str) {
	int icounter;
	int tmp_val;
	int tcnter;
	int minus_flag;
	int number_zero;

	icounter = 0;
	tmp_val=value;
	tcnter=0;
	minus_flag=0;
	number_zero=0;

	if(value<0){
		value*=-1;
		minus_flag=1;
		tcnter++;
	}
	while (tmp_val){tmp_val =tmp_val/10; tcnter++;}
	if(decimal_zero > tcnter){
		number_zero=decimal_zero-tcnter;
		tcnter+=number_zero;
	}
	if(decimal_zero < 0 || tcnter > len_str){
		return icounter;
	}
	while (value){
		dest_ptr[icounter++] = (value%10) + '0';
		value =value/10;
		if(decimal_zero==icounter){
			dest_ptr[icounter++] ='.';
		}
	}
	while(number_zero){
		dest_ptr[icounter++] ='0';
		number_zero--;
	}
	if(minus_flag){dest_ptr[icounter++] ='-';}

	flipstr(dest_ptr,icounter);
	dest_ptr[icounter] = '\0';
	return icounter;
}


/****************************************************************
 * History of Changes
 * --------------------------------------------------------------
 * Revision	Date		Author		Description
 * 0.1		06/05/2014	10012885	First Implementation.
 * 
 * 
 */
