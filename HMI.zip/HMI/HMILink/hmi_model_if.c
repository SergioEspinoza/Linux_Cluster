/*******************************************************************************
*  $Log: hmi_model_if.c  $
*  Revision 1.1 2016/10/05 16:52:30CDT Daniel Kageff (10011932) 
*  Initial revision
*  Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/HMILink/project.pj
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved.
*  This document is protected by the copyright law of the United States and
*  foreign countries.  The work embodied in this document is confidential and
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of
*  this document and any use or disclosure of this document or the work
*  embodied in it without the written authority of Yazaki North America, Inc.,
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/********************************************************************************************
*  File:  hmi_model_interface.c
*
*  Description: This file contains the interface to the HMI model.
*
********************************************************************************************/
#define HMI_MODEL_INTERFACE_C

/*******************************************************************************************/
/*    I N C L U D E   F I L E S                                                            */
/*******************************************************************************************/
#include "hmi_ss_cfg.h"
#include "hmi_priv.h"
#include "altia.h"
#include <stdint.h>


#if defined(ENABLE_VS_MACROSTEP_DEBUG) | defined(ENABLE_VS_ACTIVE_STATE_LOG) | defined(ENABLE_CONTRADICTION_REPORT)
    #include <string.h>
    #include <assert.h>
    #include <stdio.h>
#endif

#if (HMI_USE_VS_STUBS != 0)
   /*
   ** Yes, including ".c" files is a non-standard practice.  It's done here only to allow
   ** stubs to be configured on/off without having to change the list of files to compile
   ** in the make file.
   */
   #include "hmi_vs_stubs.c"
#else
   #include "HMIControlSystemSemTypes.h"
   #include "HMIControlSystemData.h"
   #include "HMIControlSystemSEMLibB.h"
   #include "HMIControlSystemAction.h"
  //TODO:ADD altia prototype
#endif  /* HMI_USE_VS_STUBS != 0 */



/*******************************************************************************************/
/*    M A C R O S                                                                          */
/*******************************************************************************************/
// add new states as needed

//uncomment for individual SM debugging
#define VS_SM_CHANGE_LOG_ALL
// update as needed
#define TRACKED_SM_SZ  3

#define VS_BUFFER_SZ             300
#define VS_ACTION_TRACE_SZ       50

#define NEXT_STATE_CONTRADICTION    1
#define GET_OUTPUT_CONTRADICTION    2

/*
** DUMMY_VS_EVENT - Dummy Visual State event (used for compiling/linking and testing without HMI model).
*/
#define DUMMY_VS_EVENT ((unsigned char) 255)
/*******************************************************************************************/
/*    T Y P E S   A N D   E N U M E R A T I O N S                                          */
/*******************************************************************************************/

/*
** HMI_EVENT_TO_VS_EVENT_RECORD - structure used to map external HMI events to Visual State events.
**    external_event - external HMI event
**    vs_event - the Visual State event corresponding to the external HMI event
*/
typedef struct
{
   HMI_EVENT_TYPE external_event;
   SEM_EVENT_TYPE vs_event;
}  HMI_EVENT_TO_VS_EVENT_RECORD;

/*******************************************************************************************/
/*    F U N C T I O N   P R O T O T Y P E S                                                */
/*******************************************************************************************/
#ifdef ENABLE_VS_MACROSTEP_DEBUG
    static void wipeActionStack( void );
    static void stackAction( SEM_ACTION_EXPRESSION_TYPE actNo );
    static void VS_Log_SM_State( int type, SEM_EVENT_TYPE event );
#endif

#ifdef ENABLE_CONTRADICTION_REPORT
static void HMIControlSystemSEM_getVSParameters( SEM_RULE_INDEX_TYPE iRI, VS_UINT8 *nPos,
											VS_UINT8 *nNxt, VS_UINT8 *nNeg,
											VS_UINT8 *nSignal, VS_UINT8 *nGuard,
											VS_UINT8 *nAction, SEM_RULE_INDEX_TYPE *PosIndex,
											SEM_RULE_INDEX_TYPE *NxtIndex, SEM_RULE_INDEX_TYPE *NegIndex,
											SEM_RULE_INDEX_TYPE *GuardIndex, SEM_RULE_INDEX_TYPE *ActionIndex);
static void HMIControlSystemSEM_ContradictionReport( void );
#endif

/*******************************************************************************************/
/*    M E M O R Y   A L L O C A T I O N                                                    */
/*******************************************************************************************/

#ifdef ENABLE_VS_MACROSTEP_DEBUG
    static SEM_ACTION_EXPRESSION_TYPE  actionList[ VS_ACTION_TRACE_SZ ];
    static int actionListIdx;
#endif

#ifdef ENABLE_VS_ACTIVE_STATE_LOG
void VS_Log_SM_StateTransitions( void );
void VS_Log_SM_print_change( int SM );
void VS_SM_Set_Initial_States( void );
// add state machine numbers to be logged
static SEM_STATE_MACHINE_TYPE trackedSMIds[ TRACKED_SM_SZ ] =
{
    1,
    2,
    3
};

//static char VS_SM_tracking_buffer[ TRACKED_SM_ID ][ VS_BUFFER_SZ ];
static SEM_STATE_TYPE activeSMState[ VS_NOF_STATE_MACHINES ];

#endif

#if defined(ENABLE_VS_MACROSTEP_DEBUG) | defined(ENABLE_VS_ACTIVE_STATE_LOG)| defined(ENABLE_CONTRADICTION_REPORT)
    static char VS_debug_buffer[ VS_BUFFER_SZ ];
    void VS_SM_print_All_SM( void );
#endif

/*
** external_event_to_vs_event_table - table used to map external events to the corresponding
**    Visual State event.
*/
static const HMI_EVENT_TO_VS_EVENT_RECORD external_event_to_vs_event_table[] =
{
   #include "HmiEventMap.cxx"
};



/*
** Diagnostic counters - these counters are incremented each time the associated condition
**    occurs and can be used for diagnosis (and checked after unit and system testing to
**    to confirm all have the value 0).
*/
static unsigned int dc_ses_not_ok_deduct = 0;
static unsigned int dc_ses_not_ok_getoutput = 0;
static unsigned int dc_ses_not_ok_next_state = 0;
static unsigned int dc_altia_error_callback = 0;
static unsigned int dc_flushoutput_return = 0;


int enabled = 0;
/********************************************************************************************
*  Function Name: MapHMIEventToVSEvent
*
*  Description: Maps an external HMI event to the corresponding VS event.
*
*  Input(s):    event - the event to be mapped (MUST be a name from the "HMI_EVENT_TYPE" enumeration).
*
*  Outputs(s):  None.
*
*  Returns:     None.
*
*  Change History:
*        2/11/2013     First version (name)
********************************************************************************************/
static SEM_EVENT_TYPE MapHMIEventToVSEvent(HMI_EVENT_TYPE external_event)
{
   unsigned int i;

   for(i=0; i<(sizeof(external_event_to_vs_event_table)/sizeof(HMI_EVENT_TO_VS_EVENT_RECORD)); ++i)
   {
      if (external_event_to_vs_event_table[i].external_event == external_event)
      {
         return(external_event_to_vs_event_table[i].vs_event);
      }
   }
   return(DUMMY_VS_EVENT);
}



/********************************************************************************************
*  Function Name:  Initialize_HMIModel
*
*  Description:  General HMI model intialization function.
*
*  Input(s):    None.
*
*  Outputs(s):  None.
*
*  Returns:     None.
*
*  Change History:
*        2/11/2013     First version (name)
********************************************************************************************/
void Initialize_HMIModel(void)
{
  
   HMIControlSystemSEM_Init();
   QueueHMIEvent(SEM_RESET);


#ifdef ENABLE_VS_ACTIVE_STATE_LOG
    // enable to print all state machines
   //VS_SM_print_All_SM(  );
#endif

}

/********************************************************************************************
*  Function Name: ProcessEvents
*
*  Description: This function processes events that have been queued to the HMI by delivering
*     them to the HMI model for processing.
*
*  Input(s):    None.
*
*  Outputs(s):  None.
*
*  Returns:     None.
*
*  Change History:
*        2/11/2013     First version (name)
********************************************************************************************/
void ProcessEvents(void)
{
   unsigned int processed_events = 0;
   unsigned char rc;
   HMI_EVENT_TYPE external_event;
   SEM_EVENT_TYPE event;
   SEM_ACTION_EXPRESSION_TYPE  action_exp;


   /*
   ** Process all events in the queue following the call sequence required by Visual State.
   */
   while (DeQueueHMIEvent(&external_event) != 0)
   {


#ifdef ENABLE_VS_MACROSTEP_DEBUG
       wipeActionStack();
#endif

      processed_events = 1;
      /*
      ** Map the external event in the queue to the corresponding event defined in the VS state machine.
      */
      event = MapHMIEventToVSEvent(external_event);
      if(event==DUMMY_VS_EVENT)
      {
        event=DUMMY_VS_EVENT;
    	  return;
      }
      rc = HMIControlSystemSEM_Deduct(event);
      if (rc != SES_OKAY)
      {
         /*
         ** TODO: decide if there anything needs to be done here besides increment a diagnostic counter.
         */
         ++dc_ses_not_ok_deduct;
#if defined(ENABLE_VS_MACROSTEP_DEBUG) | defined(ENABLE_VS_ACTIVE_STATE_LOG)| defined(ENABLE_CONTRADICTION_REPORT)
         printf("\n\nError number %u of type %u at HMIControlSystemSEM_Deduct\n", dc_ses_not_ok_deduct, rc);
#endif
      }


        while ((rc = HMIControlSystemSEM_GetOutput(&action_exp)) == SES_FOUND)
        {

#ifdef ENABLE_VS_MACROSTEP_DEBUG
            stackAction( action_exp );
#endif
            HMIControlSystemSEM_Action(action_exp);
            ++processed_events;
            if (processed_events > 2)
            {
            // printf( "ProcessEvents:  expect action 2: %u  %u (processed_events=%u)\n", rc, action_exp, processed_events);
            }
        }
        if (rc != SES_OKAY)
        {
            /*
            ** TODO: decide if there anything needs to be done here besides increment a diagnostic counter.
            */
            ++dc_ses_not_ok_getoutput;
#if defined(ENABLE_VS_MACROSTEP_DEBUG) | defined(ENABLE_VS_ACTIVE_STATE_LOG)| defined(ENABLE_CONTRADICTION_REPORT)
            printf("\n\nError number %u of type %u at HMIControlSystemSEM_GetOutput\n", dc_ses_not_ok_getoutput, rc);
#endif
#ifdef ENABLE_CONTRADICTION_REPORT
          HMIControlSystemSEM_ContradictionReport();
#endif
        }

#ifdef ENABLE_VS_MACROSTEP_DEBUG
        if( rc != SES_OKAY )
        {
            if( enabled )
            {
                VS_Log_SM_State( GET_OUTPUT_CONTRADICTION, event );
            }
        }
#endif

      rc = HMIControlSystemSEM_NextState();
      if (rc != SES_OKAY )
      {
         /*
         ** TODO: decide if there anything needs to be done here besides increment a diagnostic counter.
         */
         ++dc_ses_not_ok_next_state;
#if defined(ENABLE_VS_MACROSTEP_DEBUG) | defined(ENABLE_VS_ACTIVE_STATE_LOG)| defined(ENABLE_CONTRADICTION_REPORT)
            printf("\n\nError number %u of type %u at HMIControlSystemSEM_NextState\n", dc_ses_not_ok_next_state, rc);
#endif
#ifdef ENABLE_CONTRADICTION_REPORT
       HMIControlSystemSEM_ContradictionReport();
#endif
      }

#ifdef ENABLE_VS_MACROSTEP_DEBUG
        if( rc != SES_OKAY  )
        {
            if( enabled )
            {
                VS_Log_SM_State(  NEXT_STATE_CONTRADICTION, event );
            }
        }
#endif
#ifdef ENABLE_VS_ACTIVE_STATE_LOG

        // case of a reset do not log all the noise
        if( external_event == SEM_RESET  )
        {
            VS_SM_Set_Initial_States();
        }
        VS_Log_SM_StateTransitions();
#endif

   }

      if (altiaFlushOutput() == -1)
      {
         /*
         ** TODO: decide if there anything needs to be done here besides increment a counter.
         */
         ++dc_flushoutput_return;
      }
}

// To use contradiction logging
// Enable:
//        - HMIControlSystemSEM_Name, HMIControlSystemSEM_Expl, HMIControlSystemSEM_State
//        from Visual State API options
//        - Name definitions for actions and states

#ifdef ENABLE_VS_MACROSTEP_DEBUG
void VS_Log_SM_State( int type, SEM_EVENT_TYPE event )
{
   SEM_ACTION_EXPRESSION_TYPE  action_exp;
    SEM_STATE_MACHINE_TYPE i = 0;
    SEM_STATE_TYPE state = 0;

    printf( "\n\n**********Visual State error dump***************\n\n" );

    if( type == NEXT_STATE_CONTRADICTION  )
    {
        printf( "\n NEXT STATE CONTRADICTION!!!  \n"  );
    }
    else if( type == GET_OUTPUT_CONTRADICTION )
    {
        printf( "\nGET OUTPUT CONTRADICTION\n" );
    }

    if(  HMIControlSystemSEM_Name( EVENT_TYPE, event, VS_debug_buffer, sizeof( VS_debug_buffer ) ) == SES_OKAY )
    {
        printf( "Visual State blamed event name:, %s\n", VS_debug_buffer );
    }
    else
    {
        printf( "Visual State unable to read blamed event name\n" );
    }

    if(  HMIControlSystemSEM_Expl( EVENT_TYPE, event, VS_debug_buffer, sizeof( VS_debug_buffer ) ) == SES_OKAY )
    {
        printf( "Visual State blamed event explanation: %s\n", VS_debug_buffer );
    }
    else
    {
        printf( "Visual State unable to read blamed event explanation \n" );
    }


    printf( "\n\n<<< action trace, last executed first >>> \n\n" );
    for( i = 1 ; i <= actionListIdx ; i ++ )
    {
        // dump order most recently executed first
        action_exp = actionList[ actionListIdx - i ];

        if( HMIControlSystemSEM_Name( ACTION_TYPE, action_exp, VS_debug_buffer, sizeof( VS_debug_buffer ) ) == SES_OKAY )
        {
            printf( "%d action name : %s\n", i, VS_debug_buffer );
        }
        else
        {
            printf( "%d action number (cannot find name): %d \n", i, action_exp  );
        }
    }

    printf( "\n\n<<< active machine & states>>> \n\n" );

    VS_SM_print_All_SM( );
}
#endif

#if defined(ENABLE_VS_ACTIVE_STATE_LOG) | defined(ENABLE_VS_MACROSTEP_DEBUG)

void VS_SM_Set_Initial_States( void )
{
    SEM_STATE_TYPE state = 0;
    SEM_STATE_MACHINE_TYPE i = 0;

    for( i = 0 ; i < VS_NOF_STATE_MACHINES ; i++ )
    {
        if ( HMIControlSystemSEM_State( i, &state ) == SES_FOUND )
        {
            activeSMState[ i ]  = state;
        }
        else
        {
            printf( "State machine %d active state not fount \n", i );
        }
    }
}


#endif

#if defined(ENABLE_VS_ACTIVE_STATE_LOG) | defined(ENABLE_VS_MACROSTEP_DEBUG)

void VS_SM_print_All_SM( void )
{
    SEM_STATE_TYPE state = 0;
    SEM_STATE_MACHINE_TYPE i = 0;

    printf( "*** Visual State active state change logging enabled *** \n\n" );

    for( i = 0 ; i < VS_NOF_STATE_MACHINES ; i++ )
    {
        if( HMIControlSystemSEM_State( i, &state ) == SES_FOUND )
        {
            // TODO: find a way to get the name
            //printf( "Analyzing state machine: %s \n", VS_debug_buffer );
            printf( "Analyzing state machine number: %d \n", i );

            if( HMIControlSystemSEM_Name( STATE_TYPE, state, VS_debug_buffer, sizeof( VS_debug_buffer ) ) == SES_OKAY )
            {
                printf( "Active state name: %s \n\n", VS_debug_buffer );
            }
            else
            {
                printf( "Active state number: %d \n\n", state );
            }
        }
        else
        {
            printf( "State machine number: %d in undefined state!!! \n", i );
        }
    }

}
#endif

#ifdef ENABLE_VS_MACROSTEP_DEBUG
void stackAction( SEM_ACTION_EXPRESSION_TYPE actNo )
{
   if( actionListIdx < VS_ACTION_TRACE_SZ )
   {
        actionList[ actionListIdx++ ] = actNo;
   }
    // make space at the end
   else
   {
        //shift one place to the left
       memcpy( &actionList[1], &actionList[0], sizeof( SEM_ACTION_EXPRESSION_TYPE ) * ( VS_ACTION_TRACE_SZ - 1 ) );
        // append
       actionList[ actionListIdx ] = actNo;
   }

}
#endif


#ifdef ENABLE_VS_MACROSTEP_DEBUG
void wipeActionStack( void )
{
    memset( actionList, 0x00, sizeof( SEM_ACTION_EXPRESSION_TYPE ) * VS_ACTION_TRACE_SZ );
    actionListIdx = 0;
}
#endif

#ifdef  ENABLE_VS_ACTIVE_STATE_LOG
void VS_Log_SM_StateTransitions( void )
{
    SEM_STATE_MACHINE_TYPE i = 0;
// track state machines
#ifdef VS_SM_CHANGE_LOG_ALL
    for( i = 0 ; i < VS_NOF_STATE_MACHINES ; i++ )
    {
       VS_Log_SM_print_change( i );
    }
#else
    for( i = 0 ; i < TRACKED_SM_SZ ; i++  )
    {
       VS_Log_SM_print_change( trackedSMIds[ i ] );
    }
#endif
}

#endif

#ifdef  ENABLE_VS_ACTIVE_STATE_LOG

void VS_Log_SM_print_change( int SM )
{
       SEM_STATE_TYPE state = 0;
        // get active state
        if( HMIControlSystemSEM_State( SM, &state ) == SES_FOUND )
        {
            if( ( activeSMState[ SM ]  != state ) )
            {
                if( HMIControlSystemSEM_Name( STATE_TYPE, state, VS_debug_buffer, sizeof( VS_debug_buffer ) ) == SES_OKAY )
                {
                    printf( "Machine %d, active state change \n", SM );
                    printf( "Destination: %s \n", VS_debug_buffer );
                    //if( HMIControlSystemSEM_Name( STATE_TYPE, activeSMState[ SM ], VS_debug_buffer, sizeof( VS_debug_buffer ) ) == SES_OKAY )
                    //{
                        //printf( "Source: %s \n", VS_debug_buffer );
                    //}
                }
                else
                {
                    printf( "State machine %d state  change: %d to %d \n", SM, activeSMState[SM], state );
                }

                activeSMState[ SM ] = state;
            }
        }
        else
        {
            printf( "State machine number: %d in undefined state!!! \n", SM );
        }

}
#endif

#ifdef ENABLE_CONTRADICTION_REPORT
static void HMIControlSystemSEM_getVSParameters( SEM_RULE_INDEX_TYPE iRI, VS_UINT8 *nPos,
											VS_UINT8 *nNxt, VS_UINT8 *nNeg,
											VS_UINT8 *nSignal, VS_UINT8 *nGuard,
											VS_UINT8 *nAction, SEM_RULE_INDEX_TYPE *PosIndex,
											SEM_RULE_INDEX_TYPE *NxtIndex, SEM_RULE_INDEX_TYPE *NegIndex,
											SEM_RULE_INDEX_TYPE *GuardIndex, SEM_RULE_INDEX_TYPE *ActionIndex)
{
	SEM_INTERNAL_TYPE i;
#if (SEM_RD_WIDTH_8_BIT && SEM_RDHW_TYPE_1 && SEM_RDHW_WIDTH_16_BIT)
    i = HMIControlSystem.RuleData[iRI++];
    *nNxt = (unsigned char)(i & 0x0Fu);
    *nAction = (unsigned char)(i >> 4u);
    i = HMIControlSystem.RuleData[iRI++];
    *nPos = (unsigned char)(i & 0x0Fu);
#if (SEM_RMN_NEGATIVE_STATE_SYNCS)
    *nNeg = (unsigned char)(i >> 4u);
#endif
#endif
#if (SEM_RD_WIDTH_8_BIT && SEM_RDHW_TYPE_2 && SEM_RDHW_WIDTH_24_BIT)
    i = HMIControlSystem.RuleData[iRI++];
    *nPos = (unsigned char)(i & 0x0Fu);
#if (SEM_RMN_NEGATIVE_STATE_SYNCS)
    *nNeg = (unsigned char)(i >> 4u);
#endif
    i = HMIControlSystem.RuleData[iRI++];
#if (SEM_RMN_GUARDS)
    *nGuard = (unsigned char)(i & 0x0Fu);
#endif
    *nNxt = (unsigned char)(i >> 4u);
    i = HMIControlSystem.RuleData[iRI++];
    *nAction = (unsigned char)(i & 0x0Fu);
#if (SEM_RMN_SIGNALS)
    *nSignal = (unsigned char)(i >> 4u);
#endif
#endif
#if (SEM_RD_WIDTH_8_BIT && SEM_RDHW_TYPE_1 && SEM_RDHW_WIDTH_32_BIT)
    *nAction = (unsigned char)HMIControlSystem.RuleData[iRI++];
    *nNxt = (unsigned char)HMIControlSystem.RuleData[iRI++];
#if (SEM_RMN_NEGATIVE_STATE_SYNCS)
    *nNeg = (unsigned char)HMIControlSystem.RuleData[iRI++];
#else
    iRI++;
#endif
    *nPos = (unsigned char)HMIControlSystem.RuleData[iRI++];
#endif
#if (SEM_RD_WIDTH_8_BIT && SEM_RDHW_TYPE_2 && SEM_RDHW_WIDTH_48_BIT)
#if (SEM_RMN_NEGATIVE_STATE_SYNCS)
    *nNeg = (unsigned char)HMIControlSystem.RuleData[iRI++];
#else
    iRI++;
#endif
    *nPos = (unsigned char)HMIControlSystem.RuleData[iRI++];
    *nNxt = (unsigned char)HMIControlSystem.RuleData[iRI++];
#if (SEM_RMN_GUARDS)
    *nGuard = (unsigned char)HMIControlSystem.RuleData[iRI];
#endif
    iRI++;
#if (SEM_RMN_SIGNALS)
    *nSignal = (unsigned char)HMIControlSystem.RuleData[iRI];
#endif
    iRI++;
    *nAction = (unsigned char)HMIControlSystem.RuleData[iRI++];
#endif
#if (SEM_RD_WIDTH_16_BIT && SEM_RDHW_TYPE_1 && SEM_RDHW_WIDTH_16_BIT)
    i = HMIControlSystem.RuleData[iRI++];
    *nPos = (unsigned char)(i & 0x0Fu);
#if (SEM_RMN_NEGATIVE_STATE_SYNCS)
    *nNeg = (unsigned char)((i >> 4u) & 0x0Fu);
#endif
    *nNxt = (unsigned char)((i >> 8u) & 0x0Fu);
    *nAction = (unsigned char)((i >> 12u) & 0x0Fu);
#endif
#if (SEM_RD_WIDTH_16_BIT && SEM_RDHW_TYPE_3 && SEM_RDHW_WIDTH_32_BIT)
    i = HMIControlSystem.RuleData[iRI++];
    *nPos = (unsigned char)(i & 0x0Fu);
#if (SEM_RMN_NEGATIVE_STATE_SYNCS)
    *nNeg = (unsigned char)((i >> 4u) & 0x0Fu);
#endif
#if (SEM_RMN_GUARDS)
    *nGuard = (unsigned char)((i >> 8u) & 0x0Fu);
#endif
    *nNxt = (unsigned char)(i >> 12u);
    i = HMIControlSystem.RuleData[iRI++];
    *nAction = (unsigned char)(i & 0x0Fu);
#if (SEM_RMN_SIGNALS)
    *nSignal = (unsigned char)((i >> 4u) & 0x0Fu);
#endif
#endif
#if (SEM_RD_WIDTH_16_BIT && SEM_RDHW_TYPE_1 && SEM_RDHW_WIDTH_32_BIT)
    i = HMIControlSystem.RuleData[iRI++];
    *nNxt = (unsigned char)(i & 0x0FFu);
    *nAction = (unsigned char)(i >> 8u);
    i = HMIControlSystem.RuleData[iRI++];
    *nPos = (unsigned char)(i & 0x0FFu);
#if (SEM_RMN_NEGATIVE_STATE_SYNCS)
    *nNeg = (unsigned char)(i >> 8u);
#endif
#endif
#if (SEM_RD_WIDTH_16_BIT && SEM_RDHW_TYPE_2 && SEM_RDHW_WIDTH_48_BIT)
    i = HMIControlSystem.RuleData[iRI++];
    *nPos = (unsigned char)(i & 0x0FFu);
#if (SEM_RMN_NEGATIVE_STATE_SYNCS)
    *nNeg = (unsigned char)(i >> 8u);
#endif
    i = HMIControlSystem.RuleData[iRI++];
#if (SEM_RMN_GUARDS)
    *nGuard = (unsigned char)(i & 0x0FFu);
#endif
    *nNxt = (unsigned char)(i >> 8u);
    i = HMIControlSystem.RuleData[iRI++];
    *nAction = (unsigned char)(i & 0x0FFu);
#if (SEM_RMN_SIGNALS)
    *nSignal = (unsigned char)(i >> 8u);
#endif
#endif
#if (SEM_RD_WIDTH_32_BIT && SEM_RDHW_TYPE_1 && SEM_RDHW_WIDTH_32_BIT)
    i = HMIControlSystem.RuleData[iRI++];
    *nPos = (unsigned char)(i & 0X0FFu);
#if (SEM_RMN_NEGATIVE_STATE_SYNCS)
    *nNeg = (unsigned char)((i >> 8u) & 0X0FFu);
#endif
    *nNxt = (unsigned char)((i >> 16u) & 0x0FFu);
    *nAction = (unsigned char)((i >> 24u) & 0x0FFu);
#endif
#if (SEM_RD_WIDTH_32_BIT && SEM_RDHW_TYPE_3 && SEM_RDHW_WIDTH_64_BIT)
    i = HMIControlSystem.RuleData[iRI++];
    *nPos = (unsigned char)(i & 0x0FFu);
#if (SEM_RMN_NEGATIVE_STATE_SYNCS)
    *nNeg = (unsigned char)((i >> 8u) & 0x0FFu);
#endif
#if (SEM_RMN_GUARDS)
    *nGuard = (unsigned char)((i >> 16u) & 0x0FFu);
#endif
    *nNxt = (unsigned char)(i >> 24u);
    i = HMIControlSystem.RuleData[iRI++];
    *nAction = (unsigned char)(i & 0x0FFu);
#if (SEM_RMN_SIGNALS)
    *nSignal = (unsigned char)((i >> 8u) & 0x0FFu);
#endif
#endif
    //printf( "\n__________________________________________\n" );
#if (VS_NOF_STATE_MACHINES != 0u)
    *PosIndex = iRI;
    //printf( "PosIndex %d\n", *PosIndex);
    iRI += *nPos;
#if (SEM_RMN_NEGATIVE_STATE_SYNCS)
    *NegIndex = iRI;
    //printf( "NegIndex %d\n", *NegIndex);
    iRI += *nNeg;
#endif
#if (SEM_RMN_GUARDS)
    if(nGuard)
    {
	    *GuardIndex = iRI;
	    //printf( "GuardIndex %d\n", *GuardIndex);
	    iRI += *nGuard;
	}
#endif
    *NxtIndex = iRI;
    //printf( "NxtIndex %d\n", *NxtIndex);
    iRI += *nNxt;	
    iRI += *nSignal;
    if (*nAction)
    {
    	*ActionIndex = iRI;
    	//printf( "ActionIndex %d\n", *ActionIndex);
    	iRI += *nAction;	
    }
#endif
    return;
}



static void HMIControlSystemSEM_ContradictionReport( void )
{
    VS_UINT32 i = 0;
    VS_UINT32 j = 0;
    VS_UINT8 errorRuleNumberOfValidPositions = 0;
    VS_UINT8 errorRuleNumberOfNextStates = 0;
    VS_UINT8 errorRuleNumberOfNegativeStates = 0;
    VS_UINT8 errorRuleNumberOfSignals = 0;
    VS_UINT8 errorRuleNumberOfGuards = 0;
    VS_UINT8 errorRuleNumberOfActions = 0;
    SEM_RULE_INDEX_TYPE errorRuleValidPositionsIndex = 0;
    SEM_RULE_INDEX_TYPE errorRuleNextStatesIndex = 0;
    SEM_RULE_INDEX_TYPE errorRuleNegativeStatesIndex = 0;
    SEM_RULE_INDEX_TYPE errorRuleGuardsIndex = 0;
    SEM_RULE_INDEX_TYPE errorRuleActionsIndex = 0;
    VS_UINT8 prevRuleNumberOfValidPositions = 0;
    VS_UINT8 prevRuleNumberOfNextStates = 0;
    VS_UINT8 prevRuleNumberOfNegativeStates = 0;
    VS_UINT8 prevRuleNumberOfSignals = 0;
    VS_UINT8 prevRuleNumberOfGuards = 0;
    VS_UINT8 prevRuleNumberOfActions = 0;
    SEM_RULE_INDEX_TYPE prevRuleValidPositionsIndex = 0;
    SEM_RULE_INDEX_TYPE prevRuleNextStatesIndex = 0;
    SEM_RULE_INDEX_TYPE prevRuleNegativeStatesIndex = 0;
    SEM_RULE_INDEX_TYPE prevRuleGuardsIndex = 0;
    SEM_RULE_INDEX_TYPE prevRuleActionsIndex = 0;
    //Replace the following two lines over the currnent table index variables for printing all transitions upto the error ocurrance.
    //SEM_RULE_TABLE_INDEX_TYPE errorRuleTableIndex = HMIControlSystem.RuleTableIndex[SEMHMIControlSystem.EventNo];
    //SEM_RULE_TABLE_INDEX_TYPE limitRuleTableIndex = SEMHMIControlSystem.iFirstR-1;
    //The following rule table index variables will gather the error transition only.
    SEM_RULE_TABLE_INDEX_TYPE errorRuleTableIndex = SEMHMIControlSystem.iFirstR-1; //This would point to the rule next to the one that triggered the error, thus is substracted by one.
    SEM_RULE_TABLE_INDEX_TYPE limitRuleTableIndex = errorRuleTableIndex; //Only print error transitions.

    while (errorRuleTableIndex <= limitRuleTableIndex)
    {
	    SEM_RULE_INDEX_TYPE errorRuleIndex = HMIControlSystem.RuleIndex[ errorRuleTableIndex ];

		printf( "\n*********************************************\n");
		printf( "nRule Index %d\n", errorRuleIndex);
	    HMIControlSystemSEM_getVSParameters( errorRuleIndex, &errorRuleNumberOfValidPositions,
	    										&errorRuleNumberOfNextStates, &errorRuleNumberOfNegativeStates,
												&errorRuleNumberOfSignals, &errorRuleNumberOfGuards,
												&errorRuleNumberOfActions, &errorRuleValidPositionsIndex,
												&errorRuleNextStatesIndex, &errorRuleNegativeStatesIndex,
												&errorRuleGuardsIndex, &errorRuleActionsIndex);
	    printf( "\n--------------------------------------------------------------------------------------\n" );
	    if(  HMIControlSystemSEM_Name( EVENT_TYPE, SEMHMIControlSystem.EventNo, VS_debug_buffer, sizeof( VS_debug_buffer ) ) == SES_OKAY )
        {
            printf( "Event: %s\tRule %u\n:", VS_debug_buffer, errorRuleTableIndex);
        }
	    if ( errorRuleNumberOfValidPositions )
	    {
	    	SEM_RULE_INDEX_TYPE prevguardIndex = 0;
	    	SEM_RULE_TABLE_INDEX_TYPE prevRuleTableIndex = HMIControlSystem.RuleTableIndex[SEMHMIControlSystem.EventNo];
	    	printf( "Origin State:\n");
	    	for ( i = 0; i <  errorRuleNumberOfValidPositions; i++ )
	    	{
	    		SEM_STATE_TYPE state = HMIControlSystem.RuleData[ errorRuleValidPositionsIndex + i ];
	    		
				if( HMIControlSystemSEM_Name( STATE_TYPE, state, VS_debug_buffer, sizeof( VS_debug_buffer ) ) == SES_OKAY )
				{
				   printf( "\t%u: %s\n", state, VS_debug_buffer );
				}
	    	}
	    	printf( "Target States:\n");
	    	for ( i = 0; i <  errorRuleNumberOfNextStates; i++ )
	    	{
	    		SEM_STATE_TYPE conflict_state = HMIControlSystem.RuleData[ errorRuleNextStatesIndex + i ];
	    		SEM_STATE_TYPE state = SEMHMIControlSystem.WSV[ HMIControlSystem.StateMachineIndex[conflict_state] ];
	    		printf( " - Error rule next state value:\n");
				if( HMIControlSystemSEM_Name( STATE_TYPE, conflict_state, VS_debug_buffer, sizeof( VS_debug_buffer ) ) == SES_OKAY )
				{
			       printf( "\t%u: %s\n", conflict_state, VS_debug_buffer );
				}
				printf( " - Previous next state value:\n");
                if( HMIControlSystemSEM_Name( STATE_TYPE, state, VS_debug_buffer, sizeof( VS_debug_buffer ) ) == SES_OKAY )
                {
                   printf( "\t%u: %s\n", state, VS_debug_buffer );
                   for ( j = prevRuleTableIndex; ( j < errorRuleTableIndex ) && ( state != STATE_UNDEFINED ) ; j++ )
                   {
                       SEM_RULE_INDEX_TYPE prevRuleIndex = HMIControlSystem.RuleIndex[ j ];
                       HMIControlSystemSEM_getVSParameters( prevRuleIndex, &prevRuleNumberOfValidPositions,
                       	                        &prevRuleNumberOfNextStates, &prevRuleNumberOfNegativeStates,
                                                &prevRuleNumberOfSignals, &prevRuleNumberOfGuards,
                                                &prevRuleNumberOfActions, &prevRuleValidPositionsIndex,
                                                &prevRuleNextStatesIndex, &prevRuleNegativeStatesIndex,
                                                &prevRuleGuardsIndex, &prevRuleActionsIndex);
                       while ( prevRuleNumberOfNextStates--)
         			   {
         			   	    if ( state == HMIControlSystem.RuleData[ prevRuleNextStatesIndex++ ] )
                            {
                            	printf( "\t* Changed by Rule : %u\n", j ) ;
                            	while ( prevRuleNumberOfGuards--)
                            	{
                            		printf( "\t* Rule Guard : %u\n", HMIControlSystem.RuleData[ prevRuleGuardsIndex++ ] );
                            	}
                            	while ( prevRuleNumberOfActions--)
                            	{
                                     SEM_ACTION_EXPRESSION_TYPE action = HMIControlSystem.RuleData[ prevRuleActionsIndex++ ];
                                     if( HMIControlSystemSEM_Name( ACTION_TYPE, action, VS_debug_buffer, sizeof( VS_debug_buffer ) ) == SES_OKAY )
                                     {
                                         printf( "\t* Rule Action : %u %s\n", action, VS_debug_buffer );
                                     }
                                     else
                                     {
                                     	 printf( "\t* Rule Action : %u\n", action );
                                     }
                            	}                            	
                            }
         			   }


                   }
                }
				

	    	}

	    	printf( "Error rule Guard:\n");
	    	for ( i = 0; i <  errorRuleNumberOfGuards; i++ )
	    	{
	    		SEM_GUARD_EXPRESSION_TYPE conflict_guard = HMIControlSystem.RuleData[ errorRuleGuardsIndex + i ];
				printf( "\t%u\n", conflict_guard );
	    	}
	    	printf( "Error rule Action:\n");
	    	for ( i = 0; i <  errorRuleNumberOfActions; i++ )
	    	{
	    		SEM_ACTION_EXPRESSION_TYPE action = HMIControlSystem.RuleData[ errorRuleActionsIndex + i ];
				if( HMIControlSystemSEM_Name( ACTION_TYPE, action, VS_debug_buffer, sizeof( VS_debug_buffer ) ) == SES_OKAY )
                {
                    printf( "\t%u: %s\n", action, VS_debug_buffer );
                }
                else
                {
                    printf( "\t%u:\n", action);
                }
	    	}

	    	
	    }
	    errorRuleTableIndex++;
	}
}
#endif



/* End of file */
