/**************************************************************************************/
/*!
 *  \file    NavLink.c
 *
 *  \brief    This is the link code bewteen Graphical model and navigation display 
 *			  items.
 *
 *  \author   D. Kageff
 *
 *  \copyright (c) Copyright 2016, Yazaki North America
 *                           All Rights Reserved
 *
 *   Unpublished, Yazaki North America Inc. All rights reserved. 
 *  This document is protected by the copyright law of the United States and 
 *  foreign countries.  The work embodied in this document is confidential and 
 *  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
 *  this document and any use or disclosure of this document or the work 
 *  embodied in it without the written authority of Yazaki North America, Inc., 
 *  will constitute copyright and trade secret infringement and will violate the
 *  rights of Yazaki North America, Inc.
 *
 *  Modification history:
 *  \version $Revision: 1.4 $
 *	 $Log: NavLink.c  $
 *	 Revision 1.4 2017/02/21 17:23:05CST Daniel Kageff (10011932) 
 *	 Changes to work with redesigned datapool manager
 *	 Revision 1.3 2017/02/16 18:42:41EST Daniel Kageff (10011932) 
 *	 Updated to support additional simulation mode configuration.
 *   Revision 1.2 2017/01/30 17:32:52EST Daniel Kageff (10011932) 
 *   Added option 2 mode to load a sequence of PNG files to the audio/navigation window
 *   Revision 1.1 2016/12/13 11:08:57EST Daniel Kageff (10011932) 
 *   Initial revision
 *   Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/HMILink/project.pj
 *
 *
 ***************************************************************************************/
#define NAVLINK_C
  
/***********************************
        INCLUDE FILES
***********************************/
#include <INTEGRITY.h>
#include <stdlib.h>
#include <stdio.h>
#include <wchar.h>

#include "gp_cfg.h"         // Common GP program configuration settings
#include "gp_types.h"       // Common GP program data type definitions
#include "gp_utils.h"       // Common GP program utility functions

#include "HMI_common.h"		// Global HMI definitions

#include "NavLink.h"

/***********************************
   Private Macros and Typedefs
***********************************/
/*! Refresh frequency control */
#define NAV_REFRESH_FREQ (100/17)		/*!< Data refresh period in video frame time units (currently 17 msec) */

#define PREV_OPT_INITVAL 0

#define NAV_FNAME_BASE	"nav_frame_"			/*!< Base filename for audio window image files */

 /***********************************
   Private Data and Structures
 **********************************/
static int	RefreshCounter;
//static uint32_t prev_options;
static uint32_t frame_cntr;			/*!< Displayed frames counter.  Rolls over at num_frames */

static uint16_t num_sim_frames;		/*!< Number of simulation frames */
static uint16_t frame_dly;			/*!< Sim inter-frame delay count */
static uint16_t frame_dly_tmr;		/*!< Sim inter-frame delay timer counter */
static int loop_dly;				/*!< Sim inter-loop delay count */
static int loop_dly_tmr;			/*!< Sim inter-loop delay timer counter */

 
 /***********************************
   Private Function Prototypes
 ***********************************/ 
 

/************ Start of code ******************/

/**************************************************************************************/
/*! \fn CbInitNav_Link()
 *
 *	\param - No parameters
 *
 *  \par Description:	  
 *   This function initializes the HMI navigation datapool linkage functions.  
 *
 *  \retval	None
 *
 *  \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
void CbInitNav_Link(void)
{
	uint16_t temp16;
	uint32_t temp32;

	RefreshCounter = 0;
	frame_cntr = 0;

	/* Initialize simulation parameters */
	GET_ELEMENT(YzTdoNavSimFrames, &num_sim_frames);
	GET_ELEMENT(YzTdoNavFrameDly, &temp16);
	frame_dly = temp16 / HMI_FRAME_TIME;
	frame_dly_tmr = 0;

	GET_ELEMENT(YzTdoNavLoopDly, &temp32);
	loop_dly = temp32 / HMI_FRAME_TIME;
	loop_dly_tmr = 0;

	CbRefreshNav_Link(true);		// Initial display of navigation display
}



/**************************************************************************************/
/*! \fn CbRefreshNav_Link(uint8_t forceupdate)
 *
 *	\param[in] forceupdate	- If non-0, then force the display to update even if the 
 *							  data hasn't changed.
 *
 *  \par Description:	  
 *   This function updates the HMI navigation display based on the audio datapool 
 *	 item values.  
 *
 *  \retval	None
 *
 *  \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
void CbRefreshNav_Link(uint8_t forceupdate)
{	
	/* Check if it is time to update the display */
	if (forceupdate == true)
	{
		RefreshCounter = NAV_REFRESH_FREQ; 	//Force the counter's timeout
	}
//	else
//	{
//		RefreshCounter++;				//Count this cycle
//	}

	/* Get the navigation display options */
	uint32_t options;
	GET_ELEMENT(YzTdoNavOpts, (int32_t *)&options);

	/* If navigation display normal operation has been enabled */
	if(options & HMI_OPT_DEMO1)
	{
		RefreshCounter++;				//Count this cycle
		if(RefreshCounter >= NAV_REFRESH_FREQ)
		{
			wchar_t wstr_image_file[MAX_PATH_LEN];		// for wide (16 bit) char string

			/* Build the image file path string */
		 	swprintf(wstr_image_file, MAX_PATH_LEN, L"./%s/%s%03d.%s", 
		 			 HMI_DEMO_DIR, NAV_FNAME_BASE, frame_cntr, IMAGE_FILE_EXT);

			/* TEMPORARY - Display static audio image */
			HMI_AltiaSendEvent(ALT_TEXT("NaviFadeInAnim"), 100);	// full fade in
			HMI_AltiaSendEvent(ALT_TEXT("nav_card"), 0);			// display it
			Hmi_AltiaSendText(ALT_TEXT("nav_0_image_name"), (AltiaCharType *)wstr_image_file);

			/* Reset refresh counter */
			RefreshCounter = 0;
		}
	}		
	/* Else if audio display simulation has been enabled */
	else if(options & HMI_OPT_SIM)
	{
		/* If it is time to update the sim frame */
		if((frame_dly_tmr <= 0) && (loop_dly_tmr == 0))
		{
			wchar_t wstr_image_file[MAX_PATH_LEN];		// for wide (16 bit) char string

			/* Build the image file path string */
		 	swprintf(wstr_image_file, MAX_PATH_LEN, L"./%s/%s%03d.%s", 
		 			 HMI_DEMO_DIR, NAV_FNAME_BASE, frame_cntr, IMAGE_FILE_EXT);

			/* Display the audio image */
			HMI_AltiaSendEvent(ALT_TEXT("NaviFadeInAnim"), 100);	// full fade in
			HMI_AltiaSendEvent(ALT_TEXT("nav_card"), 0);			// display it
			Hmi_AltiaSendText(ALT_TEXT("nav_0_image_name"), (AltiaCharType *)wstr_image_file);

			/* Reset inter-frame delay timer */
			frame_dly_tmr = frame_dly;

			/* Incr sim frame counter */
			frame_cntr++;			/* Update display frame counter */
			if(frame_cntr > num_sim_frames)
			{
				frame_cntr = 0;
				loop_dly_tmr = loop_dly;	// Reset loop delay timer
			}
		}
		/* If we are at the 1st frame and the inter-loop timer is active */
		if((frame_cntr == 0) && (loop_dly_tmr > 0))
		{
			/* If the display is to be blanked during the loop delay */
			if((loop_dly_tmr == (loop_dly-1)) && ((options & HMI_OPT_SIM_BLNK) == HMI_OPT_SIM_BLNK))
			{
				HMI_AltiaSendEvent(ALT_TEXT("nav_card"), -1);
			}
			/* Decrement timer counter */
			loop_dly_tmr--;

			/* If we are ready to restart the loop */
			if(loop_dly_tmr <= 0)
			{
				frame_dly_tmr = 0;		// Force inter-frame timer to 'expired'
			}
		}
		/* Update inter-frame delay timer */
		if(frame_dly_tmr > 0)
		{
			frame_dly_tmr--;
		}
	}
	/* Turn display off */
	else
	{
		HMI_AltiaSendEvent(ALT_TEXT("nav_card"), -1);
		frame_dly_tmr = 0;
		loop_dly_tmr = 0;
	}
}
