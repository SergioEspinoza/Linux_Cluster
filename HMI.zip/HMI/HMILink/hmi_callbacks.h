/*******************************************************************************
*  $Log: hmi_callbacks.h  $
*  Revision 1.1 2016/09/13 13:52:06CDT Daniel Kageff (10011932) 
*  Initial revision
*  Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/HMILink/project.pj
*  Revision 1.11 2015/04/20 17:40:23CDT Sergio Espinoza Lopez (10012599) 
*  PARTIAL [SP_ISSUE_ID_2172] Group02 should be ignored while system check
*  Revision 1.10 2015/01/13 17:15:12CST Fernando Villarreal Garza (10011234) 
*  Added ISG Screen and refresh for ISG pop-ups
*  Revision 1.9 2014/10/23 10:45:52CDT Sergio Espinoza Lopez (10012599) 
*  SPAS beep callbacks added into states that needed it
*  Revision 1.9 2014/09/08 18:32:59CDT Sergio Espinoza (10012599)
*  spas beep callback
*  Revision 1.8 2014/09/08 18:32:59CDT Fernando Villarreal Garza (10011234) 
*  HMI release 2.11
*  Revision 1.7 2014/08/25 14:41:30CDT Kevin Russo (10032877) 
*  add callbacks for active popup, page, selection
*  Revision 1.6 2014/08/14 20:17:59EDT Edgar Rios Lucas (10032297) 
*  HMI Update - Refer to release notes for details
*  Revision 1.5 2014/06/05 07:45:07CDT Gregory Palarski (10030324) 
*  Remove prototype for ResetRange function as this function was removed from the HMI model.
*  Revision 1.4 2014/06/04 15:19:45EDT Gregory Palarski (10030324) 
*  Added prototypes for callback functions.
*  Revision 1.3 2014/06/03 13:39:24EDT Edgar Rios (10032297) 
*  Releasing HMI 1.0
*  Release notes and change analysis pending
*  Revision 1.2 2014/06/02 08:29:37CDT Kevin Russo (kevinadm) 
*  Member moved from hmi_callbacks.h in project /Projects/Hyundai/2016_KiaQLIPC/Software Development/Eng/Application/Include/project.pj to hmi_callbacks.h in project /Projects/Hyundai/2016_KiaQLIPC/Software Development/Eng/HMI/Link/project.pj.
*  Revision 1.1 2014/04/17 13:10:00EDT Gregory Palarski (10030324) 
*  Initial revision
*  Member added to project /Projects/Hyundai/2016_KiaQLIPC/Software Development/Eng/Application/Include/project.pj
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/********************************************************************************************
*  File:  hmi_callbacks.h 
*
*  Description: This file contains prototypes for callback functions the HMI Model invokes to interact 
*     with the system.
********************************************************************************************/
#ifndef HMI_CALLBACKS_H   
#define HMI_CALLBACKS_H   

/*******************************************************************************************/
/*    I N C L U D E   F I L E S                                                            */
/*******************************************************************************************/
#include "hmi_ss.h"
/*******************************************************************************************/
/*    M A C R O S                                                                          */
/*******************************************************************************************/



/*******************************************************************************************/
/*    T Y P E S   A N D   E N U M E R A T I O N S                                          */
/*******************************************************************************************/


/*******************************************************************************************/
/*    F U N C T I O N   P R O T O T Y P E S                                                */
/*******************************************************************************************/


/********************************************************************************************
*  Function Name: Dummy_Callback
*
*  Description:  Dummy callback function for integration and test.
*
*  Input(s):    None. 
*
*  Outputs(s):  None.
*
*  Returns:     None.
********************************************************************************************/
void Dummy_Callback(void);



#endif
/* End of file */
