/**************************************************************************************/
/*!
 *    \file    	HMI_versions.h
 *
 *    \copyright Yazaki 2016
 *
 *    \brief 	Holds version/revision information for the HMI program and modules.
 *				It is important that this version/revision information be updated 
 *				when the HMI program code is changed.
 *
 *    \author   D. Kageff
 *
 *  Modification history:
 *   $Log: HMI_versions.h  $
 *   Revision 1.8 2017/06/16 10:38:39CDT Daniel Kageff (10011932) 
 *   Updated revision
 *   Revision 1.7 2017/02/28 10:00:50EST Daniel Kageff (10011932) 
 *   Updated revision (for new prewarp cal reading)
 *   Revision 1.6 2017/02/23 08:52:02EST Daniel Kageff (10011932) 
 *   Updated revision
 *   Revision 1.5 2017/02/15 18:22:39EST Daniel Kageff (10011932) 
 *   Updated revision
 *   Revision 1.4 2017/01/24 15:22:38EST Daniel Kageff (10011932) 
 *   Changed version/revision to 2.0 to indicate change to HMI where graphics assets are loaded from the flash filesystem.
 *   Revision 1.3 2017/01/10 17:30:59EST Daniel Kageff (10011932) 
 *   Updated revision
 *   Revision 1.2 2016/12/13 11:36:56EST Daniel Kageff (10011932) 
 *   Updated revision
 *   Revision 1.1 2016/12/07 10:22:56EST Daniel Kageff (10011932) 
 *   Initial revision
 *   Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/project.pj
 *
 */
/***************************************************************************************/

#ifndef HMI_VERSIONS_H
#define HMI_VERSIONS_H


/**************************************************************/
/* 		HMI program version and configuration information 	  */ 
/**************************************************************/
#define HMI_MAIN_VER 2		 /*!< HMI Manager program version. Displayed in startup banner. */
#define HMI_MAIN_REV 4		 /*!< HMI Manager program revision.  Displayed in startup banner. */

#endif		// end HMI_VERSIONS_H
