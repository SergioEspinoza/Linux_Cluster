/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/**************************************************************************************/
/*!
 *    \file    	HmiDisplayManager.h
 *
 *    \copyright Yazaki 2016
 *
 *    \brief 	Header file containing the public interfaces and data for the TBD
 *				software component.
 *
 *    \author   Fernando V.
 *
 *    \version	$Revision: 1.2 $  $Log $
 *
 */
/***************************************************************************************/

#ifndef HMIDISPLAYMANAGER_H
#define HMIDISPLAYMANAGER_H

/***********************************
		   INCLUDE FILES
***********************************/

/***********************************
	Public Macros and Typedefs
***********************************/

/***********************************
	Public Data and Structures
***********************************/

/**********************************************************
				Public Function Prototypes
	(Instrumented function headers are in the .c file)
***********************************************************/
/**************************************************************************************/
/*  DisplayManagerInit ( void )
 *
 *
 *  Description:
 *  This function is called after the module is returned from sleep return data from the buRAM
 *
 **************************************************************************************/
 void DisplayManagerInit(void);
 /**************************************************************************************/
 /*   DisplayManagerSetScreen ( void )
  *
  *
  *  Description:
  *  This function is called after the module is returned from sleep return data from the buRAM
  *
  **************************************************************************************/
 void DisplayManagerSetScreen(uint8_t Screen);
 /**************************************************************************************/
 /*  DisplayManagerRefreshScreen ( void )
  *
  *
  *  Description:
  *  This function is called after the module is returned from sleep return data from the buRAM
  *
  **************************************************************************************/
 void DisplayManagerRefreshScreen(uint8_t Screen);
 
#endif /*HMIDISPLAYMANAGER_H*/
/*!
  @}  End of RamMgr group
*/

/* End of file */