/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/*******************************************************************************************!
*  \addtogroup ...
*  @{
********************************************************************************************/

/**************************************************************************************/
/*!
 *  \file    TurnSignalLink.c
 *
 *  \brief    this is the link code bewteen Graphical model and datapool item
 *
 *  \author   Fernando V.
 *
 *  Modification history:
 *   $Log: TurnSignalLink.c  $
 *   Revision 1.5 2016/12/12 16:07:36CST Fernando Villarreal Garza (10011234) 
 *   changed animation to used 30ms step and update FF logo animation
 *   Revision 1.4 2016/12/08 10:12:01CST Fernando Villarreal Garza (10011234) 
 *   Added animations for the white lanes during blinking 
 *   added defines for the magic numbers and animations names used
 *   Revision 1.3 2016/12/06 10:38:57CST Fernando Villarreal Garza (10011234) 
 *   changes for Hmi 2 Version
 *   Revision 1.1 2016/10/06 15:00:10EDT Daniel Kageff (10011932) 
 *   Initial revision
 *   Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/HMILink/project.pj
 *
 *
 ***************************************************************************************/
  #define TURNSIGNALLINK_C
  
  /***********************************
        INCLUDE FILES
 ***********************************/
 #include "TurnSignalLink.h"
 #include "GraphicModelCfg.h"
 #include "datainterface.h"
 
 /***********************************
   Private Macros and Typedefs
 ***********************************/
 /*! \brief ...... */
#define REFRESH_FREQ		(1)	/* Data refresh frequency threshold */

#define TIMER_BLINK_LIMIT   (33) //1000/30 1seg period
#define TIMER_BLINK_ON      (16) //500/30ms

#define TURN_HAZZARD_STATE  (0)
#define TURN_LEFT_STATE     (1)
#define TURN_RIGHT_STATE    (2)
#define TURN_IDLE_STATE     (3)

 /***********************************
   Private Data and Structures
 **********************************/
 static uint8_t	RefreshCounter;
 static uint32_t BlinkTimerCnt = 0;
 /***********************************
   Private Function Prototypes
 ***********************************/ 
 void StartTimer(void);
 uint8_t GetTimerState(void);
 void UpdateTimerState(void);
 
 /**************************************************************************************/
 /*! \fn CbInitTurnSignal_Link
 *
 *
 *  \par Description:
 *  This function initlize all variables of the Battery icon status 
 *
 **************************************************************************************/
 void CbInitTurnSignal_Link(void)
 {
     RefreshCounter = 0;
     CbRefreshTurnSignal_Link(true);
 }
 
 /**************************************************************************************/
 /*! \fn CbRefreshTurnSignal_Link
 *
 *
 *  \par Description:
 *  This Function do the refresh status of the Battery icon and the bar 
 *
 **************************************************************************************/
 void CbRefreshTurnSignal_Link(uint8_t forceupdate)
 {
     int32_t turnleftValue = 0;
     int32_t turnRightValue = 0;	
     int32_t HazzardValue = 0;	

     static uint8_t CurrentState = 0;
     static uint8_t PrevState = 0;
     if (forceupdate == true)
     {
         RefreshCounter = REFRESH_FREQ; 	//Force the counter's timeout
     }else
     {
         RefreshCounter++;				//Count this cycle
     }
 
     if(RefreshCounter >= REFRESH_FREQ)
     {
         //Enable Turn Signal state
         HMI_AltiaSendEvent(TURN_SIG_SELECT,TURN_SIG_ENABLE);
         
         //Get data from Datapool
         GET_ELEMENT(YzTdTurnLeftSig,&turnleftValue);
         GET_ELEMENT(YzTdTurnRightSig,&turnRightValue);
         GET_ELEMENT(YzTdHazard, &HazzardValue);
         
         // Hide all before enable the required 
         HMI_AltiaSendEvent(TURN_LEFT_GREEN_LANE_ANIM_NAME,TURN_SIG_DISABLE);     
         HMI_AltiaSendEvent(TURN_LEFT_GREEN_ANIM_NAME,TURN_SIG_DISABLE);          
         HMI_AltiaSendEvent(TURN_RIGHT_GREEN_LANE_ANIM_NAME,TURN_SIG_DISABLE);   
         HMI_AltiaSendEvent(TURN_RIGHT_GREEN_ANIM_NAME,TURN_SIG_DISABLE);        
         HMI_AltiaSendEvent(TURN_LEFT_RED_LANE_ANIM_NAME,TURN_SIG_DISABLE);    
         HMI_AltiaSendEvent(TURN_LEFT_RED_ANIM_NAME,TURN_SIG_DISABLE);        
         HMI_AltiaSendEvent(TURN_RIGHT_RED_LANE_ANIM_NAME,TURN_SIG_DISABLE);  
         HMI_AltiaSendEvent(TURN_RIGHT_RED_ANIM_NAME,TURN_SIG_DISABLE);
         
         
         //Hazzard
         if(HazzardValue != 0)
         {
             CurrentState = TURN_HAZZARD_STATE;
             if(CurrentState != PrevState) StartTimer();
             
             HMI_AltiaSendEvent(TURN_WHITE_LANE_RIGHT_ENABLE,TURN_SIG_DISABLE);
             HMI_AltiaSendEvent(TURN_WHITE_LANE_LEFT_ENABLE,TURN_SIG_DISABLE);
             
             HMI_AltiaSendEvent(TURN_LEFT_RED_LANE_ANIM_NAME,TURN_SIG_ENABLE);
             HMI_AltiaSendEvent(TURN_RIGHT_RED_LANE_ANIM_NAME,TURN_SIG_ENABLE);
             
             HMI_AltiaSendEvent(TURN_LEFT_RED_ANIM_NAME,GetTimerState());
             HMI_AltiaSendEvent(TURN_RIGHT_RED_ANIM_NAME,GetTimerState());

        //Left Blinking
         }else if(turnleftValue != 0 )
         {
             CurrentState = TURN_LEFT_STATE;
             if(CurrentState != PrevState) StartTimer();
             
             HMI_AltiaSendEvent(TURN_WHITE_LANE_RIGHT_ENABLE,TURN_SIG_ENABLE);
             HMI_AltiaSendEvent(TURN_WHITE_LANE_LEFT_ENABLE,TURN_SIG_DISABLE);
             
             HMI_AltiaSendEvent(TURN_LEFT_GREEN_LANE_ANIM_NAME,TURN_SIG_ENABLE);
             HMI_AltiaSendEvent(TURN_RIGHT_GREEN_LANE_ANIM_NAME,TURN_SIG_DISABLE);
         
             HMI_AltiaSendEvent(TURN_LEFT_GREEN_ANIM_NAME,GetTimerState());
             HMI_AltiaSendEvent(TURN_RIGHT_GREEN_ANIM_NAME,TURN_SIG_DISABLE);
         
         
         //Right Blinking
         }else if(turnRightValue != 0)
         {
             CurrentState = TURN_RIGHT_STATE;
             if(CurrentState != PrevState) StartTimer();
             
             HMI_AltiaSendEvent(TURN_WHITE_LANE_RIGHT_ENABLE,TURN_SIG_DISABLE);
             HMI_AltiaSendEvent(TURN_WHITE_LANE_LEFT_ENABLE,TURN_SIG_ENABLE);
             
             HMI_AltiaSendEvent(TURN_LEFT_GREEN_LANE_ANIM_NAME,TURN_SIG_DISABLE);
             HMI_AltiaSendEvent(TURN_RIGHT_GREEN_LANE_ANIM_NAME,TURN_SIG_ENABLE);

             HMI_AltiaSendEvent(TURN_LEFT_GREEN_ANIM_NAME,TURN_SIG_DISABLE);
             HMI_AltiaSendEvent(TURN_RIGHT_GREEN_ANIM_NAME,GetTimerState());


         }else
         {
             CurrentState = TURN_IDLE_STATE;
             StartTimer();
             
             HMI_AltiaSendEvent(TURN_WHITE_LANE_RIGHT_ENABLE,TURN_SIG_ENABLE);
             HMI_AltiaSendEvent(TURN_WHITE_LANE_LEFT_ENABLE,TURN_SIG_ENABLE);
             
             HMI_AltiaSendEvent(TURN_LEFT_GREEN_LANE_ANIM_NAME,TURN_SIG_DISABLE);
             HMI_AltiaSendEvent(TURN_RIGHT_GREEN_LANE_ANIM_NAME,TURN_SIG_DISABLE);

             HMI_AltiaSendEvent(TURN_LEFT_GREEN_ANIM_NAME,TURN_SIG_DISABLE);
             HMI_AltiaSendEvent(TURN_RIGHT_GREEN_ANIM_NAME,TURN_SIG_DISABLE);
         }
         
         PrevState = CurrentState;
         UpdateTimerState();
     }
 }
 
 /**************************************************************************************/
 /*! \fn StartTimer
 *
 *
 *  \par Description:
 *  This Function do the refresh status of the Battery icon and the bar 
 *
 **************************************************************************************/
 void StartTimer(void)
 {
     BlinkTimerCnt = 0;
 }
 /**************************************************************************************/
 /*! \fn GetTimerState
 *
 *
 *  \par Description:
 *  This Function do the refresh status of the Battery icon and the bar 
 *
 **************************************************************************************/
 uint8_t GetTimerState(void)
 {
     uint8_t ret;
     if(BlinkTimerCnt <= TIMER_BLINK_ON) 
     {
         ret = TURN_SIG_ENABLE;
     }else
     {
         ret = TURN_SIG_DISABLE;
     }     
     return ret;
 }
 /**************************************************************************************/
 /*! \fn UpdateTimerState
 *
 *
 *  \par Description:
 *  This Function do the refresh status of the Battery icon and the bar 
 *
 **************************************************************************************/
 void UpdateTimerState(void)
 {
     BlinkTimerCnt++;
     if(BlinkTimerCnt >= TIMER_BLINK_LIMIT) StartTimer();
 }
 /*!
   @}  \todo
 */
 /* End of file */
