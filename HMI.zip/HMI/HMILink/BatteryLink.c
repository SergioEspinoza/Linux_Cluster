/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/*******************************************************************************************!
*  \addtogroup ...
*  @{
********************************************************************************************/

/**************************************************************************************/
/*!
 *  \file    batteryLink.c
 *
 *  \brief    this is the link code bewteen Graphical model and datapool item
 *
 *  \author   Fernando V.
 *
 *  Modification history:
 *   $Log: BatteryLink.c  $
 *   Revision 1.1 2016/09/13 13:56:22CDT Daniel Kageff (10011932) 
 *   Initial revision
 *   Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/HMILink/project.pj
 *
 *
 ***************************************************************************************/
  #define BATTERYLINK_C
  
  /***********************************
        INCLUDE FILES
 ***********************************/
 #include "BatteryLink.h"
 #include "GraphicModelCfg.h"
 #include "datainterface.h"
 
 /***********************************
   Private Macros and Typedefs
 ***********************************/
 /*! \brief ...... */
#define REFRESH_FREQ		(1)	/* Data refresh frequency threshold */

#define BATTERY_STEP        (10)
 /***********************************
   Private Data and Structures
 **********************************/
 static uint8_t	RefreshCounter;
 
 /***********************************
   Private Function Prototypes
 ***********************************/ 
 
 /**************************************************************************************/
 /*! \fn DisplayManagerInit
 *
 *
 *  \par Description:
 *  This function initlize all variables of the Battery icon status 
 *
 **************************************************************************************/
 void CbInitBattery_Link(void)
 {
     RefreshCounter = 0;
     CbRefreshBattery_Link(true);
 }
 
 /**************************************************************************************/
 /*! \fn CbRefreshBattery_Link
 *
 *
 *  \par Description:
 *  This Function do the refresh status of the Battery icon and the bar 
 *
 **************************************************************************************/
 void CbRefreshBattery_Link(uint8_t forceupdate)
 {	
     uint8_t    batteryValue = 0;

     if (forceupdate == true)
     {
         RefreshCounter = REFRESH_FREQ; 	//Force the counter's timeout
     }else
     {
         RefreshCounter++;				//Count this cycle
     }
 
     if(RefreshCounter >= REFRESH_FREQ)
     {
         
         GET_ELEMENT(YzTdBattery,&batteryValue);
         batteryValue /= BATTERY_STEP;
         if(batteryValue > BATTERY_DISPAY_BAR_ANIM_MAX) batteryValue = BATTERY_DISPAY_BAR_ANIM_MAX;
         HMI_AltiaSendEvent(BATTERY_DISPAY_BAR_ANIM_NAME,batteryValue);
         HMI_AltiaSendEvent(BATTERY_DISPAY_ICON_ANIM_NAME,batteryValue);
     }
 }
 
 /*!
   @}  \todo
 */
 /* End of file */
