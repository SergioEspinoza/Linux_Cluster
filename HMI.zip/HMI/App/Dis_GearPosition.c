/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/**************************************************************************************/
/*!
 *  \file    Dis_GearPosition.c
 *
 *  \brief    This module is a gateway between CAN and SPI messages to the GP 
 *
 *  \author    Fernando V.
 *
 *  Modification history:
 *   $Log: Dis_GearPosition.c  $
 *   Revision 1.3 2016/12/05 16:25:14CST Daniel Kageff (10011932) 
 *   Changes to use signed integers for the datapool items and to use common datapool management/access functions between the GP app and HMI
 *   Revision 1.2 2016/11/15 15:57:50EST Fernando Villarreal Garza (10011234) 
 *   removed blocking of the prndl state event
 *   Revision 1.1 2016/10/05 15:26:42CDT Daniel Kageff (10011932) 
 *   Initial revision
 *   Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/App/project.pj
 *
 *
 ***************************************************************************************/
 
 #define DIS_GEARPOSITION_C
 
 /***********************************
        INCLUDE FILES
 ***********************************/
 #include "Dis_GearPosition.h"
 #include "datainterface.h"
 #include "hmi_priv.h"
 /***********************************
   Private Macros and Typedefs
 ***********************************/
 
 /***********************************
   Private Data and Structures
 ***********************************/

const APPState Dis_GearPosition =
{
	GearPosition_StartupInit,
	GearPosition_PeriodicTask,
};

 /***********************************
   Private Function Prototypes
 ***********************************/
 
 
/**************************************************************************************/
/*! \fn GearPosition_StartupInit ( void )
*
*
*  \par Description:
*  This function is called at the startup of the HMI and initialize the state of the Gear state
*
**************************************************************************************/
  
void GearPosition_StartupInit(void)
{
}
 
/**************************************************************************************/
/*! \fn GearPosition_PeriodicTask ( void )
*
*
*  \par Description:
*  This function read the Gear state and  trigger an event to the state machine
*
**************************************************************************************/
  
void GearPosition_PeriodicTask(void)
{
    int32_t GearPosition = 0;
    GET_ELEMENT(YzTdPRNDL,&GearPosition);
    if(GearPosition == GearPosition_P)
    {
        HMISS_PostHMIEvent(GEAR_CHANGE_TO_P_EVENT);
    }
    if(GearPosition != GearPosition_P)
    {
        HMISS_PostHMIEvent(GEAR_DRIVE_EVENT);
    }
}
