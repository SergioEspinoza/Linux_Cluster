/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/

/**************************************************************************************/
/*!
*    \file    	Dis_Common.h
*
*    \copyright Yazaki 2016
*
*    \brief 	Header file containing the public interfaces and data for the Gear position
*
*    \author   Fernando Villarreal
*
*    Modification history:
*    $Log: Dis_Common.h  $
*    Revision 1.1 2016/09/13 12:25:46CDT Daniel Kageff (10011932) 
*    Initial revision
*    Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/App/project.pj
*
*/
/***************************************************************************************/

#ifndef DIS_COMMON_H
#define DIS_COMMON_H

typedef void (*VoidReturnFunc)(void);

typedef struct
{
	VoidReturnFunc Init;
	VoidReturnFunc Periodic;
} APPState;


#endif
 /* End of file */
