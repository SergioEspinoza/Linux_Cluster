/**************************************************************************************/
/*!
 *  \file    DynPowerLink.h
 *
 *  \brief    This is the public interface for the link code bewteen Graphical model  
 *			  and dynamic power datapool items.
 *
 *  \author   D. Kageff
 *
 *  \copyright (c) Copyright 2016, Yazaki North America
 *                           All Rights Reserved
 *
 *   Unpublished, Yazaki North America Inc. All rights reserved. 
 *  This document is protected by the copyright law of the United States and 
 *  foreign countries.  The work embodied in this document is confidential and 
 *  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
 *  this document and any use or disclosure of this document or the work 
 *  embodied in it without the written authority of Yazaki North America, Inc., 
 *  will constitute copyright and trade secret infringement and will violate the
 *  rights of Yazaki North America, Inc.
 *
 *  Modification history:
 *  \version $Log: DynPowerLink.h  $
 *  \version Revision 1.1 2016/12/05 17:21:27CST Daniel Kageff (10011932) 
 *  \version Initial revision
 *  \version Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/HMILink/project.pj
 *
 *
 ***************************************************************************************/
#ifndef DYNPOWERLINK_H
#define DYNPOWERLINK_H

/***********************************
      INCLUDE FILES
***********************************/
#include "datainterface.h"

/***********************************
  Private Macros and Typedefs
***********************************/

/***********************************
   Function Prototypes
***********************************/ 

/**************************************************************************************/
/*! \fn CbDynPower_Link
*
*
*  \par Description:
*  This function initializes the dynamic power datapool linkage functions. 
*
**************************************************************************************/
void CbInitDynPower_Link(void);

/**************************************************************************************/
/*! \fn CbRefreshDynPower_Link
*
*
*  \par Description:
*  This function updates the dynamic power HMI display item. 
*
**************************************************************************************/
void CbRefreshDynPower_Link(uint8_t forceupdate);


#endif		// End DYNPOWERLINK_H