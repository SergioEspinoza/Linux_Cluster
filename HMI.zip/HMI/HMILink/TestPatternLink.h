/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/********************************************************************************************
*  \file  TestPatternLink.h 
*
*  \author Fernando Villarreal 
*
*  \brief This module control the battery status and send the values to the Altia model
*
*  Modification history:
*   $Log: TestPatternLink.h  $
*   Revision 1.1 2016/10/06 13:59:38CDT Daniel Kageff (10011932) 
*   Initial revision
*   Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/HMILink/project.pj
********************************************************************************************/

#ifndef TESTPATTERNLINK_H
#define TESTPATTERNLINK_H

/***********************************
      INCLUDE FILES
***********************************/
#include "datainterface.h"

/***********************************
  Private Macros and Typedefs
***********************************/

/***********************************
   Function Prototypes
***********************************/ 

/**************************************************************************************/
/*! \fn DisplayManagerInit
*
*
*  \par Description:
*  This function initlize all variables of the Battery icon status 
*
**************************************************************************************/
void CbInitTestPattern_Link(void);

/**************************************************************************************/
/*! \fn CbRefreshBattery_Link
*
*
*  \par Description:
*  This Function do the refresh status of the Battery icon and the bar 
*
**************************************************************************************/
void CbRefreshTestPattern_Link(uint8_t forceupdate);

#endif
/*!
  @}  End of TestPattern group
*/

/* End of file */
