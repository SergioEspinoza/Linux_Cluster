/**************************************************************************************/
/*!
 *  \file		Hmi_mgr_as.c
 *
 *  \copyright	Yazaki 2016
 *
 *  \brief		Top level FF HUD application HMI manager functions.  This software component
 *				initializes and starts the HMI.
 *
 *  \author		E. Gunarta, D. Kageff
 *
 *  \version	$Revision: 1.23 $  
 *				$Log: Hmi_mgr_as.c  $
 *				Revision 1.23 2017/06/20 10:15:57CDT Daniel Kageff (10011932) 
 *				In main(), changed APP_DIR to HMI_BASE_DIR (defined in gp_cfg.h)
 *				Revision 1.22 2017/05/10 10:05:15EDT Eudora Gunarta (10031829) 
 *				Moved time constants to clk_api.h, adjusted scheduling of next alarm to be closer to 30msec.
 *				Revision 1.21 2017/05/09 10:41:40EDT Eudora Gunarta (10031829) 
 *				Changes for measuring HMI task execution time.
 *				Revision 1.20 2017/03/31 14:02:14EDT Eudora Gunarta (10031829) 
 *				Changes for GP reset request.
 *				Revision 1.19 2017/03/17 12:59:17EDT Eudora Gunarta (10031829) 
 *				Changed all transfers with with other tasks to be buffer type.
 *				Replaced printf() with gp_printf().
 *				Revision 1.18 2017/02/17 17:08:56EST Daniel Kageff (10011932) 
 *				1) Fixed timeout for calls to Msg_SyncTxBuf()
 *				2) Reformatted some code
 *
 ***************************************************************************************
 * \page sw_component_overview Software Component Overview page
 *	This optional comment section can be used to create an overview page for this 
 *	software component that is accessable from the navigation pane of the gnerated 
 *	design document.
 *
 *  TODO LIST:
 */
/***************************************************************************************/
#define _HMI_MGR_AS_C		/*!< File label definition */

/***********************************
		   INCLUDE FILES
***********************************/
#include <INTEGRITY.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>			// Required for chdir()

#include "gp_cfg.h"         // Common GP program configuration settings
#include "gp_types.h"       // Common GP program data type definitions
#include "gp_utils.h"       // Common GP program utility functions

#include "clk_api.h"
#include "msg_buf.h"
#include "msg_api.h"
#include "msg_def.h"
#include "msg_fcn.h"

#include "Datapool.h"

//#include "altiaUserMain.h"	// Altia HMI functions
#include "hmi_ss.h"
#include "Vivante.h"			// HMI stress test functions
#include "HMI_versions.h"		// HMI program verion information

#include "Hmi_mgr_int.h"	// Definitions from Integrate file

#ifdef HMI_EN_CHRONO
#include "chrono.h"
#endif

/***********************************
	Private Macros and Typedefs
***********************************/
/*! Holds info about an INTEGRITY Connection message */
typedef struct {
    uint32_t ActId;	/*!< Activity ID */
    uint32_t BufSz;	/*!< Receive buffer size */
    uint32_t BufIdx;	/*!< Index into receive buffer */
    uint8_t * Buf;	/*!< Pointer to receive buffer. */
} TskInfoType;

/***********************************
	               Config Macros
***********************************/
/*!< List of TskInfoType entries */
enum {
    RX_UM_1 = 0,
    RX_ALARM,
    TSKINFO_NUM_ENTRIES
};

/*!< Size of buffer used for receiving messages on Hm_UmAsCon1 connection */
#define UMASCON1_BUF_SZ 4

#define GET_CONN_WAIT_TIME_SEC	1		/*!< Number of seconds to wait between attempts to get a connection 
											 obejct from the Resource Manager */

#define NUM_RSC_RETRIES		10		/*!< Number of times to try and get a resource from the resource manager
										 before giving up. */

/***********************************
	Private Data and Structures
***********************************/
/* INTEGRITY Connection messages */
static TskInfoType TskInfo[TSKINFO_NUM_ENTRIES];

/*! Connection to the Unit Manager */
Connection HmAs_UmAsCon1;

/*! Connection to the IPC Manager */
Connection HmAs_ImAsCon1;

uint8_t HmiSleepReq = 0;
uint8_t HmiSleepReady = 0;

#ifdef HMI_EN_CHRONO
CHRONO_BUFF cm_hmi_periodic_task;
#endif

/***********************************
	Private Function Prototypes
***********************************/
void IntTsk_HmiAlarmHandler(uint32_t data, uint32_t size);
void IntTsk_UmasRxHandler(uint32_t data, uint32_t size);
static gp_retcode_t GetConnections(void);
static int32_t SendVideoReadyMsg(uint8_t data);
static int32_t ProcHbtReq(uint8_t * data, uint32_t size);

/************ Start of code ******************/

/**************************************************************************************/
/*! \fn main()
 *
 *	param - No parameters
 *
 *  \par Description:	  
 *   Main entry point of the HMI Manager component.  
 *
 *  \retval	None
 *
 *  \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
int main()
{
    Error err;
    int32_t ret;
    gp_retcode_t rc;

    gp_Printf(DFLT_DBG_PRNTLVL, "\n************************************************\n");
    gp_Printf(DFLT_DBG_PRNTLVL, " Yazaki FF HUD HMI Application v %d.%d\n", HMI_MAIN_VER, HMI_MAIN_REV);
    gp_Printf(DFLT_DBG_PRNTLVL, " Build date: %s\n", __DATE__ );
    gp_Printf(DFLT_DBG_PRNTLVL, " Includes Altia Deepscreen support\n");
    gp_Printf(DFLT_DBG_PRNTLVL, "************************************************\n");
#ifdef DEBUG    
    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: Started\n");
#endif /* DEBUG */

    /* Init data pool */
    do {
	rc = InitPool();
	if(rc != GP_SUCCESS) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: InitPool() error %d\n", rc);
	}
    } while(rc != GP_SUCCESS);

    /* Init msg bufs */
    do {
	rc = Msg_InitBufs();
	if(rc != GP_SUCCESS) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: Msg_InitBufs() error %d\n", rc);
	}
    } while(rc != GP_SUCCESS);

    /* Init msg api */
    do {
	rc = Msg_InitApi();
	if(rc != GP_SUCCESS) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: Msg_InitApi() error %d\n", rc);
	}
    } while(rc != GP_SUCCESS);

    /* Start DataTsk AFTER init data pool, msg bufs and msg api */
    do {
	err = RunTask(Hm_DplTsk);
	if(err != Success) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: RunTask() error %d\n", err);
	}
    } while(err != Success);

    /* Get connections to other application managers */
    do {
	rc = GetConnections();
	if(rc != GP_SUCCESS) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "HMAS_INTTSK: Can't get resources!\n");
	}
    } while(rc != GP_SUCCESS);

#ifndef HMI_STRESS_TEST
    /* Make 'mydisk' the default directory and start the HMI */
	chdir(HMI_BASE_DIR);
	{
	  char curr_path[MAX_PATH_LEN];
	  getcwd(curr_path, MAX_PATH_LEN-2);
	  gp_Printf(DFLT_DBG_PRNTLVL, "CWD: %s\n", curr_path);
	}
    HMISS_StartupInit();
#else
    /* Start HMI stress test */
    StartVivanteDemo();
#endif
    
    /* Send video ready signal to VP ONLY if HMI startup was ok */
    do {
	ret = SendVideoReadyMsg(1);
	if(ret != 0) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: SendVideoReadyMsg() error %d\n", ret);
	}
    } while(ret != 0);


    /* Start rx buf msgs from UM */
    do {
	TskInfo[RX_UM_1].Buf = Msg_GetBuf(UMASCON1_BUF_SZ,
		&TskInfo[RX_UM_1].BufSz,
		&TskInfo[RX_UM_1].BufIdx);
	if(TskInfo[RX_UM_1].Buf == NULL) 
	{
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: Msg_GetBuf(UM) error\n");
	}
    } while(TskInfo[RX_UM_1].Buf == NULL);
    do {
	rc = Msg_AsyncRxBuf((Object)HmAs_UmAsCon1,
		&TskInfo[RX_UM_1].ActId,
		PRIORITY_LOW,
		TskInfo[RX_UM_1].Buf,
		TskInfo[RX_UM_1].BufSz,
		IntTsk_UmasRxHandler);
	if(rc != GP_SUCCESS) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: Msg_AsyncRxBuf(UM) error %d\n", rc);
	}
    } while(rc != GP_SUCCESS);

    /* Start hmi alarm */
    do {
	rc = Clk_SetTimer(Hm_Clk, false, MSEC_30);
	if(rc != GP_SUCCESS) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: Clk_SetTimer() error %d\n", rc);
	}
    } while(rc != GP_SUCCESS);
    do {
	rc = Msg_AsyncRxEvent((Object)Hm_Clk,
		&TskInfo[RX_ALARM].ActId,
		PRIORITY_LOW,
		IntTsk_HmiAlarmHandler);
	if(rc != GP_SUCCESS) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: Msg_AsyncRxEvent(alarm) error %d\n", rc);
	}
    } while(rc != GP_SUCCESS);

#ifdef HMI_EN_CHRONO
    ChronoInitBuff(&cm_hmi_periodic_task);
#endif

    /* Main HMI manager loop */
    while(1) 
    {
	/* Wait for callbacks */
	rc = Msg_WaitForAsyncTxRx();
	if(rc != GP_SUCCESS) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: Msg_WaitForAsyncTxRx() error %d\n", rc);
	}
    }
}

/**************************************************************************************/
/*! \fn IntTsk_HmiAlarmHandler(uint32_t data, uint32_t size)
 *
 *	param[in] data	- ignore since this is an event
 *	param[in] size	- ignore since this is an event
 *
 *  \par Description:	  
 *   Handle HMI screen update timer.  
 *
 *  \retval	Returns 0 if OK, non-0 if error.
 *
 *  \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
void IntTsk_HmiAlarmHandler(uint32_t data, uint32_t size)
{
    gp_retcode_t rc;
    int32_t ret;
    Time start_time, end_time;
    int64_t delta_usec, delta_msec, next_msec;
    static uint32_t counter = 0;
    static uint32_t counter_1000ms = 0;

    GetClockTime(HighResClock, &start_time);

    counter++;
    if(counter >= 3) {
	/* Re-send video ready signal in case IPC failed to service this
	   request */
	ret = SendVideoReadyMsg(1);
	if(ret != 0) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: SendDataToImAs() error %d\n", ret);
	}
	counter = 0;
    }

#ifdef HMI_EN_CHRONO
    ChronoBeginMeas(cm_hmi_periodic_task);
#endif
    HMISS_PeriodicTask();
#ifdef HMI_EN_CHRONO
    ChronoEndMeas(cm_hmi_periodic_task);
#endif
    counter_1000ms++;
    if(counter_1000ms > 30) {
	counter_1000ms = 0;
#ifdef HMI_EN_CHRONO
	printf("HMISS_PeriodicTask: %*lld us\n", 8, cm_hmi_periodic_task.delta_usec);
#endif
    }

    /* Start hmi alarm */
    GetClockTime(HighResClock, &end_time);
    Clk_GetDeltaTime(start_time, end_time, &delta_usec);
    delta_msec = delta_usec/1000u;
    next_msec = MSEC_30 - ( delta_msec - ((delta_msec/MSEC_30)*MSEC_30) );
    do {
	rc = Clk_SetTimer(Hm_Clk, false, next_msec);
	if(rc != GP_SUCCESS) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: Clk_SetTimer() error %d\n", rc);
	}
    } while(rc != GP_SUCCESS);
    do {
	rc = Msg_AsyncRxEvent((Object)Hm_Clk,
		&TskInfo[RX_ALARM].ActId,
		PRIORITY_LOW,
		IntTsk_HmiAlarmHandler);
	if(rc != GP_SUCCESS) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: Msg_AsyncRxEvent(alarm) error %d\n", rc);
	}
    } while(rc != GP_SUCCESS);
}

/**************************************************************************************/
/*! \fn IntTsk_UmasRxHandler(uint32_t data, uint32_t size)
 *
 *	param[in] data	- data received
 *	param[in] size	- number of bytes received
 *
 *  \par Description:	  
 *   Handle Unit Manager message receive event.  
 *
 *  \retval	Returns 0 if OK, non-0 if error.
 *
 *  \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
void IntTsk_UmasRxHandler(uint32_t data, uint32_t size)
{
    gp_retcode_t rc;
    int32_t ret;
    uint16_t msgId;
    uint8_t * msgDt;
    int offset;

    msgDt = (uint8_t *)data;
    offset = gp_Read16bit(&msgId, &msgDt[0]);
    switch(msgId) {

	case HbtReq:
	    /* This is a periodic request, so if the
	       following fails just log and continue */
	    ret = ProcHbtReq(&msgDt[offset], (size - offset));
	    if(ret != 0) {
		gp_Printf(DFLT_DBG_PRNTLVL, "\nDMAS_INTTSK: ProcHbtReq() error %d\n", ret);
	    }
	    break;

	default:
	    break;
    }

    /* Wait for messages from the Unit Manager */
    do {
	rc = Msg_AsyncRxBuf((Object)HmAs_UmAsCon1,
		&TskInfo[RX_UM_1].ActId,
		PRIORITY_LOW,
		TskInfo[RX_UM_1].Buf,
		TskInfo[RX_UM_1].BufSz,
		IntTsk_UmasRxHandler);
	if(rc != GP_SUCCESS) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: Msg_AsyncRxBuf(UM) error %d\n", rc);
	}
    } while(rc != GP_SUCCESS);
}

/**************************************************************************************/
/*! \fn GetConnections()
 *
 *	param[in] None
 *
 *  \par Description:	  
 *   Get connections to the Unit and Datapool managers.  
 *
 *  \retval	result of type ::gp_retcode_t - 0 = Success, -1 = Error 
 *
 *  \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
static gp_retcode_t GetConnections()
{
    gp_retcode_t retcode = GP_SUCCESS;
    Error err;
    int retries;

    /* Request Unit Manager connection from resource mgr */
    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: Requesting UM connections...");
    retries = NUM_RSC_RETRIES;
    do 
    {
    	err = RequestResource((Object *)&HmAs_UmAsCon1, UM_HMI_TASK_CON, NULL);
		if(err != Success)
		{
		    sleep(GET_CONN_WAIT_TIME_SEC);
		    retries--;
		}
    } while((err != Success) && (retries > 0));

    if(err == Success)
    {
		gp_Printf(DFLT_DBG_PRNTLVL, "Success\n");
    }
    else
    {
		gp_Printf(DFLT_DBG_PRNTLVL, "Failed - %d\n", err);
		retcode = GP_INIT_ERR;
    }

    /* Request IPC Manager connection from resource mgr */
    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_INTTSK: Requesting IM connection...");
    retries = NUM_RSC_RETRIES;
    do 
    {
    	err = RequestResource((Object *)&HmAs_ImAsCon1, IM_HMI_TASK_CON, NULL);
	if(err != Success)
	{
	    sleep(GET_CONN_WAIT_TIME_SEC);
	    retries--;
	}
    } while((err != Success) && (retries > 0));
    if(err == Success)
    {
		gp_Printf(DFLT_DBG_PRNTLVL, "Success\n");
    }
    else
    {
		gp_Printf(DFLT_DBG_PRNTLVL, "Failed - %d\n", err);
		retcode = GP_INIT_ERR;
    }
    
    return retcode;
}

/**************************************************************************************/
/*! \fn static int32_t SendVideoReadyMsg(Connection conn, uint8_t data)
 *
 *      param[in] conn	- connection to be used for transfers
 *	param[in] data	- data to send
 *
 *  \par Description:	  
 *   Sends VideoReady message with given data on given connection.
 *
 *  \retval	Returns 0 if OK, non-0 if error.
 *
 *  \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
static int32_t SendVideoReadyMsg(uint8_t data)
{
    return (TxBufMsg((Object)HmAs_ImAsCon1,
	    VideoReady,
	    &data,
	    sizeof(data),
	    IPC_GEN_TIMEOUT));
}

/**************************************************************************************/
/*! \fn int32_t ProcHbtReq(uint8_t * data, uint32_t size)
 *
 *	param[in] data	- pointer to the message
 *	param[in] size	- number of bytes in the message
 *
 *  \par Description:	  
 *   Process the heartbeat request message by parsing the message and sending a hearbeat
 *   response back.
 *
 *  \returns 0 of no errors else non-zero if error
 *
 *  \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
static int32_t ProcHbtReq(uint8_t * data, uint32_t size)
{
    uint8_t hbtRes[2];

    /* Check if there is sleep mode request in the message */
    if( (data[0] == MSG_HBTREQ_MODE_1) || (data[0] == MSG_HBTREQ_MODE_2) ) {
	HmiSleepReq = 1;
    } else {
	HmiSleepReq = 0;
    }

    //Simulate HMI code set HmiSleepReady = 1:
    HmiSleepReady = 1;

    /* Compose response */
    hbtRes[0] = TSK_OK;
    if(HmiSleepReady == 1) {
	hbtRes[1] = MSG_HBTRES_MODE_1;
    } else {
	hbtRes[1] = MSG_HBTRES_MODE_0;
    }

    /* Send response to UM */
    return (TxBufMsg((Object)HmAs_UmAsCon1,
	    HbtHmIntTsk,
	    &hbtRes[0],
	    sizeof(hbtRes),
	    IPC_HBT_TIMEOUT));
}

