/**************************************************************************************/
/*!
 *  \file		Hmi_mgr_as.c
 *
 *  \copyright	Yazaki 2016
 *
 *  \brief		Top level FF HUD application HMI manager functions.  This software component
 *				initializes and starts the HMI.
 *
 *  \author		E. Gunarta, D. Kageff
 *
 *  \version	$Revision: 1.9 $  
 *				$Log $
 *
 ***************************************************************************************
 * \page sw_component_overview Software Component Overview page
 *	This optional comment section can be used to create an overview page for this 
 *	software component that is accessable from the navigation pane of the gnerated 
 *	design document.
 *
 *  TODO LIST:
 */
/***************************************************************************************/
#define _HMI_MGR_AS_WORKTASK1_C		/*!< File label definition */

/***********************************
		   INCLUDE FILES
***********************************/
#include <INTEGRITY.h>
#include <stdlib.h>
#include <stdio.h>

#include "gp_cfg.h"         // Common GP program configuration settings
#include "gp_types.h"       // Common GP program data type definitions
#include "gp_utils.h"       // Common GP program utility functions

#include "clk_api.h"
#include "msg_buf.h"
#include "msg_api.h"
#include "msg_def.h"
#include "msg_fcn.h"

#include "Datapool.h"		// Datapool access functions
#include "pool_def.h"		// Global datapool definitions.

#include "Hmi_mgr_int.h"	// Definitions from Integrate file

/***********************************
	Private Macros and Typedefs
***********************************/
/*! Holds info about an INTEGRITY Connection message */
typedef struct {
    uint32_t ActId;			/*!< Activity ID */
    uint32_t BufSz;			/*!< Receive buffer size */
    uint32_t BufIdx;		/*!< Index into receive buffer */
    uint8_t * Buf;			/*!< Pointer to receive buffer. */
} TskInfoType;

/***********************************
	               Config Macros
***********************************/
/*!< List of TskInfoType entries */
enum {
    RX_UM_1 = 0,
    RX_ALARM,
    TSKINFO_NUM_ENTRIES
};

/*!< Size of buffer used for receiving messages on Hm_UmAsCon2 connection */
#define UMASCON2_BUF_SZ 4

#define GET_CONN_WAIT_TIME_SEC	1		/*!< Number of seconds to wait between attempts to get a connection 
											 obejct from the Resource Manager */

#define NUM_RSC_RETRIES		10		/*!< Number of times to try and get a resource from the resource manager
										 before giving up. */

/***********************************
	Private Data and Structures
***********************************/
/* INTEGRITY Connection messages */
static TskInfoType TskInfo[TSKINFO_NUM_ENTRIES];

/* Used for prewarp in driver.c */
int32_t WarpMesh = 0;
int32_t WarpContent = 0;
int32_t MirrorPosShort = 0;
int32_t MirrorPosMed = 0;
int32_t MirrorPosTall = 0;
int32_t MirrorPos = 0;

/*! Connection to the Unit Manager */
Connection HmAs_UmAsCon2;

/*! Connection to the Datapool Manager */
Connection HmAs_PmAsCon1;

/***********************************
	Private Function Prototypes
***********************************/
void DplTsk_UmasRxHandler(uint32_t data, uint32_t size);
void DplTsk_HmiAlarmHandler(uint32_t data, uint32_t size);
static gp_retcode_t GetConnections(void);
static int32_t ProcHbtReq(uint8_t * data, uint32_t size);

/************ Start of code ******************/

/**************************************************************************************/
/*! \fn Hm_DisplayTskMain()
 *
 *	param - No parameters
 *
 *  \par Description:	  
 *   Main entry point of the HMI Manager component.  
 *
 *  \retval	None
 *
 *  \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
int Hm_DplTskMain()
{
    gp_retcode_t rc;

    gp_Printf(DFLT_DBG_PRNTLVL, "\nHM_DPLTSK: Started\n");

    /* Init msg bufs */
    do 
    {
		rc = Msg_InitBufs();
		if(rc != GP_SUCCESS) 
		{
		    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_DPLTSK: Msg_InitBufs() error %d\n", rc);
		}
    } while(rc != GP_SUCCESS);

    /* Init msg api */
    do 
    {
		rc = Msg_InitApi();
		if(rc != GP_SUCCESS) 
		{
		    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_DPLTSK: Msg_InitApi() error %d\n", rc);
		}
    } while(rc != GP_SUCCESS);

    /* Get connections to other application managers */
    do 
    {
		rc = GetConnections();
		if(rc != GP_SUCCESS) 
		{
		    gp_Printf(DFLT_DBG_PRNTLVL, "HMAS_DPLTSK: Can't get resources!\n");
		}
    } while(rc != GP_SUCCESS);

    /* Start rx buf msgs from UM */
    do {
	TskInfo[RX_UM_1].Buf = Msg_GetBuf(UMASCON2_BUF_SZ,
		&TskInfo[RX_UM_1].BufSz,
		&TskInfo[RX_UM_1].BufIdx);
	if(TskInfo[RX_UM_1].Buf == NULL) 
	{
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nDMAS_INTTSK: Msg_GetBuf(UM) error\n");
	}
    } while(TskInfo[RX_UM_1].Buf == NULL);
    do {
	rc = Msg_AsyncRxBuf((Object)HmAs_UmAsCon2,
		&TskInfo[RX_UM_1].ActId,
		PRIORITY_LOW,
		TskInfo[RX_UM_1].Buf,
		TskInfo[RX_UM_1].BufSz,
		DplTsk_UmasRxHandler);
	if(rc != GP_SUCCESS) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nDMAS_INTTSK: Msg_AsyncRxBuf(UM) error %d\n", rc);
	}
    } while(rc != GP_SUCCESS);

    /* Start hmi alarm */
    do 
    {
		rc = Clk_SetTimer(Hm_DplClk, false, MSEC_15);
		if(rc != 0) 
		{
		    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_DPLTSK: Clk_SetTimer() error %d\n", rc);
		}
    } while(rc != 0);
    do 
    {
		rc = Msg_AsyncRxEvent((Object)Hm_DplClk,
			&TskInfo[RX_ALARM].ActId,
			PRIORITY_LOW,
			DplTsk_HmiAlarmHandler);
		if(rc != 0) 
		{
		    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_DPLTSK: Msg_AsyncRxEvent(alarm) error %d\n", rc);
		}
    } while(rc != 0);

    /* Main HMI manager loop */
    while(1) 
    {
		/* Wait for callbacks */
		rc = Msg_WaitForAsyncTxRx();
		if(rc != 0) 
		{
		    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_DPLTSK: Msg_WaitForAsyncTxRx() error %d\n", rc);
		}
    }
}

/**************************************************************************************/
/*! \fn DplTsk_UmasRxHandler(uint32_t data, uint32_t size)
 *
 *	param[in] data	- data received
 *	param[in] size	- number of bytes received
 *
 *  \par Description:	  
 *   Handle Unit Manager message receive event.  
 *
 *  \retval	Returns 0 if OK, non-0 if error.
 *
 *  \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
void DplTsk_UmasRxHandler(uint32_t data, uint32_t size)
{
    gp_retcode_t rc;
    int32_t ret;
    uint16_t msgId;
    uint8_t * msgDt;
    int offset;

    msgDt = (uint8_t *)data;
    offset = gp_Read16bit(&msgId, &msgDt[0]);
    switch(msgId) {

	case HbtReq:
	    /* This is a periodic request, so if the
	       following fails just log and continue */
	    ret = ProcHbtReq(&msgDt[offset], (size - offset));
	    if(ret != 0) {
		gp_Printf(DFLT_DBG_PRNTLVL, "\nDMAS_INTTSK: ProcHbtReq() error %d\n", ret);
	    }
	    break;

	default:
	    break;
    }

    do {
	rc = Msg_AsyncRxBuf((Object)HmAs_UmAsCon2,
		&TskInfo[RX_UM_1].ActId,
		PRIORITY_LOW,
		TskInfo[RX_UM_1].Buf,
		TskInfo[RX_UM_1].BufSz,
		DplTsk_UmasRxHandler);
	if(rc != GP_SUCCESS) {
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nDMAS_INTTSK: Msg_AsyncRxBuf(UM) error %d\n", rc);
	}
    } while(rc != GP_SUCCESS);
}

/**************************************************************************************/
/*! \fn DplTsk_HmiAlarmHandler(uint32_t data, uint32_t size)
 *
 *	param[in] data	- ignore since this is an event
 *	param[in] size	- ignore since this is an event
 *
 *  \par Description:	  
 *   Handle HMI screen update timer.  
 *
 *  \retval	none
 *
 *  \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
void DplTsk_HmiAlarmHandler(uint32_t data, uint32_t size)
{
    gp_retcode_t rc;
    int32_t ret;
    PoolCopyResType Msg;
    uint32_t transferred = 0;

    /* Get copy of the datapool from the Datapool Manager */

    /* Send the datapool copy request */
    ret = TxBufMsg((Object)HmAs_PmAsCon1, PoolCopyReq, NULL, 0, IPC_DP_HMI_TIMEOUT);
    if(ret != 0) {
	gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_DPLTSK: TxBufMsg(PM) error %d\n", ret);
    } else {
	/* Wait (indefinitely) to receive datapool copy */
	rc = Msg_SyncRxBuf((Object)HmAs_PmAsCon1, (uint8_t *)&Msg, sizeof(Msg), 0, &transferred);

	/* If the datapool was received correctly then update the local datapool */
	if( (Msg.Id == PoolCopyRes) && (transferred == sizeof(Msg)) ) 
	{
	    SetPool(&Msg.Dt);
	}

	/* Update local data parameters from the datapool */
	GetElem(YzTdWarpMesh, &WarpMesh);
	GetElem(YzTdWarpContent, &WarpContent);
	GetElem(YzTdMirrorPosShort, &MirrorPosShort);
	GetElem(YzTdMirrorPosMed, &MirrorPosMed);
	GetElem(YzTdMirrorPosTall, &MirrorPosTall);
	GetElem(YzTdMirrorPos, &MirrorPos);
    }
    
    /* Start HMI alarm for periodic datapool requests */
    do 
    {
	rc = Clk_SetTimer(Hm_DplClk, false, MSEC_30);
	if(rc != GP_SUCCESS) 
	{
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_DPLTSK: Clk_SetTimer() error %d\n", rc);
	}
    } while(rc != GP_SUCCESS);

    /* Register the HMI datapool timeout handler */
    do 
    {
	rc = Msg_AsyncRxEvent((Object)Hm_DplClk, &TskInfo[RX_ALARM].ActId,
		PRIORITY_LOW, DplTsk_HmiAlarmHandler);
	if(rc != GP_SUCCESS) 
	{
	    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_DPLTSK: Msg_AsyncRxEvent(alarm) error %d\n", rc);
	}
    } while(rc != GP_SUCCESS);
}

/**************************************************************************************/
/*! \fn GetConnections()
 *
 *	param[in] None
 *
 *  \par Description:	  
 *   Get connections to the Unit and Datapool managers.  
 *
 *  \retval	result of type ::gp_retcode_t - 0 = Success, -1 = Error 
 *
 *  \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
static gp_retcode_t GetConnections(void)
{
    gp_retcode_t retcode = GP_SUCCESS;
    Error err;
    int retries;

    /* Request Unit Manager connection from resource mgr */
    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_DPLTSK: Requesting UM connection...");
    retries = NUM_RSC_RETRIES;
    do 
    {
    	err = RequestResource((Object *)&HmAs_UmAsCon2, UM_HMI_DPLTASK_CON, NULL);
		if(err != Success)
		{
		    sleep(GET_CONN_WAIT_TIME_SEC);
		    retries--;
		}
    } while((err != Success) && (retries > 0));

    if(err == Success)
    {
		gp_Printf(DFLT_DBG_PRNTLVL, "Success\n");
    }
    else
    {
		gp_Printf(DFLT_DBG_PRNTLVL, "Failed - %d\n", err);
		retcode = GP_INIT_ERR;
    }
    
    /* Request Datapool Manager connection from resource mgr */
    gp_Printf(DFLT_DBG_PRNTLVL, "\nHMAS_DPLTSK: Requesting PM connection...");
    retries = NUM_RSC_RETRIES;
    do 
    {
    	err = RequestResource((Object *)&HmAs_PmAsCon1, PM_HMI_TASK_CON, NULL);
	if(err != Success)
	{
	    sleep(GET_CONN_WAIT_TIME_SEC);
	    retries--;
	}
    } while((err != Success) && (retries > 0));
    if(err == Success)
    {
		gp_Printf(DFLT_DBG_PRNTLVL, "Success\n");
    }
    else
    {
		gp_Printf(DFLT_DBG_PRNTLVL, "Failed - %d\n", err);
		retcode = GP_INIT_ERR;
    }
    
    return retcode;
}

/**************************************************************************************/
/*! \fn int32_t ProcHbtReq(uint8_t * data, uint32_t size)
 *
 *	param[in] data	- pointer to the message
 *	param[in] size	- number of bytes in the message
 *
 *  \par Description:	  
 *   Process the heartbeat request message by parsing the message and sending a hearbeat
 *   response back.
 *
 *  \returns 0 of no errors else non-zero if error
 *
 *  \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
static int32_t ProcHbtReq(uint8_t * data, uint32_t size)
{
    uint8_t status[1];

    status[0] = TSK_OK;
    
    return (TxBufMsg((Object)HmAs_UmAsCon2,
	    HbtHmDplTsk,
	    &status[0],
	    sizeof(status),
	    IPC_HBT_TIMEOUT));
}
