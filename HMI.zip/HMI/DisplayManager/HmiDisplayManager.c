/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/**************************************************************************************/
/*!
 *  \file    HmiDisplayManager.c
 *
 *  \brief    This module is the Display control of the animations in the HMI 
 *
 *  \author    Fernando V.
 *
 *  Modification history:
 *   $Log: HmiDisplayManager.c  $
 *   Revision 1.10 2016/12/13 15:19:20CST Fernando Villarreal Garza (10011234) 
 *   update build up animation table to run in 30ms and configurable to remove audio and navi animation
 *   Revision 1.9 2016/12/13 10:13:06CST Daniel Kageff (10011932) 
 *   1) Disabled audio and nav opening animations. 2) Added audio and nav display controls to set and refresh screen functions.
 *   Revision 1.8 2016/12/12 18:14:16EST Daniel Kageff (10011932) 
 *   Added calls to navigation item display control functions.
 *   Revision 1.7 2016/12/09 14:01:39EST Fernando Villarreal Garza (10011234) 
 *   added init functions
 *   Revision 1.6 2016/12/08 13:07:18CST Daniel Kageff (10011932) 
 *   Turned off beta watermark
 *   Revision 1.5 2016/12/08 11:31:39EST Fernando Villarreal Garza (10011234) 
 *   Added animations for the white lanes during blinking 
 *   added defines for the magic numbers and animations names used
 *   Revision 1.4 2016/12/06 17:44:29CST Fernando Villarreal Garza (10011234) 
 *   added dummy event *still working on build up animation*
 *   Revision 1.3 2016/12/06 10:58:17CST Fernando Villarreal Garza (10011234) 
 *   Changes for HMI 2nd Version
 *   Revision 1.1 2016/10/06 16:39:34EDT Daniel Kageff (10011932) 
 *   Initial revision
 *   Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/DisplayManager/project.pj
 *
 *
 ***************************************************************************************/
 
 #define HMIDISPLAYMANAGER_C
 
 
 /***********************************
       INCLUDE FILES
***********************************/
#include "HMIControlSystemConstants.h"
#include "HMIControlSystemData.h"
#include "datainterface.h"
#include "GraphicModelCfg.h"
//#include "BatteryLink.h"
#include "PRNDLink.h"
#include "TurnSignalLink.h"
#include "SpeedLink.h"
#include "TestPatternLink.h"
#include "DynPowerLink.h"
#include "NavLink.h"				// Navigation display control
#include "AudioLink.h"				// Audio display control

/***********************************
  Private Macros and Typedefs
***********************************/
typedef struct {
    uint32_t InitialStep;
    uint32_t EndStep;
    uint8_t AltiaStepVar;
    uint8_t Dir;
    uint8_t step;
    AltiaCharType AltiaEvent[40];
    uint16_t* AltiaVar;
}Opening_Data;

 
/***********************************
  Private Data and Structures
***********************************/
/*! Animation step for FF logo */
static uint16_t OpeningState = 0;
/*! build up animation step  */
static uint32_t animationstep =0;

#define INCREMENTAL 0
#define DECREMENTAL 1

/*! Animation step count variables */
uint16_t RangeLabelAnim = 0;
uint16_t ChgLabelAnim = 0;
uint16_t EcoLabelAnim = 0;
uint16_t PwrLabelAnim = 0;

uint16_t ButtomBarAnim = 0;

uint16_t EcoBarAnim = 0;
uint16_t PwrBarAnim = 0;
uint16_t MiBarAnim = 0;
uint16_t ChgBarAnim = 0;

uint16_t EyeBrowsAnim = 0;
uint16_t SpeedVisibleAnim = 0;
uint16_t SpeedBuildAnim = 0;
uint16_t DriveModeAnim = 0;
uint16_t NaviFadeInAnim = 0;
uint16_t AudioFadeInAnim = 0;
uint16_t WhiteLaneAnim = 0;

/*! Opening animation event list table This table is generated from BuildUpRef.xlsx*/
Opening_Data OpeningDef[] = 
{
    {0	,	15	,	0	,	      INCREMENTAL	,	2	,	  ALT_TEXT("range_build_animation")	,	&RangeLabelAnim	}	,
    {0	,	15	,	0	,	      INCREMENTAL	,	2	,	  ALT_TEXT("chg_build_animation")	,	&ChgLabelAnim	}	,
    {15	,	30	,	0	,	      INCREMENTAL	,	2	,	  ALT_TEXT("eco_build_animation")	,	&EcoLabelAnim	}	,
    {30	,	45	,	0	,	      INCREMENTAL	,	2	,	  ALT_TEXT("pwr_build_animation")	,	&PwrLabelAnim	}	,
    {45	,	60	,	0	,	      INCREMENTAL	,	2	,	  ALT_TEXT("bottom_bar_build_animation")	,	&ButtomBarAnim	}	,
    {60	,	70	,	0	,	      INCREMENTAL	,	5	,	  ALT_TEXT("eco_bar_animation")	,	&EcoBarAnim	}	,
    {70	,	90	,	0	,	      INCREMENTAL	,	5	,	  ALT_TEXT("pwr_bar_animation")	,	&PwrBarAnim	}	,
    {90	,	115	,	0	,	      INCREMENTAL	,	2	,	  ALT_TEXT("mi_bar_animation")	,	&MiBarAnim	}	,
    {90	,	100	,	100	,	     DECREMENTAL	,	10	,	  ALT_TEXT("pwr_bar_animation")	,	&PwrBarAnim	}	,
    {100	,	105	,	50	,	     DECREMENTAL	,	10	,	  ALT_TEXT("eco_bar_animation")	,	&EcoBarAnim	}	,
    {105	,	110	,	0	,	     INCREMENTAL	,	10	,	  ALT_TEXT("chg_bar_animation")	,	&ChgBarAnim	}	,
    {110	,	124	,	0	,	     INCREMENTAL	,	1	,	  ALT_TEXT("eyebrows_reveal_animation")	,	&EyeBrowsAnim	}	,
    {124	,	139	,	0	,	     INCREMENTAL	,	2	,	  ALT_TEXT("speed_build_animation")	,	&SpeedBuildAnim	}	,
    {124	,	139	,	0	,	     INCREMENTAL	,	2	,	  ALT_TEXT("drive_mode_build_animation")	,	&DriveModeAnim	}	,
    {139	,	164	,	50	,	     DECREMENTAL	,	2	,	  ALT_TEXT("chg_bar_animation")	,	&ChgBarAnim	}	,
    {164	,	174	,	0	,	     INCREMENTAL	,	10	,	  ALT_TEXT("NaviFadeInAnim")	,	&NaviFadeInAnim	}	,
    {174	,	184	,	0	,	     INCREMENTAL	,	10	,	  ALT_TEXT("AudioFadeInAnim")	,	&AudioFadeInAnim	}	,
    {184	,	198	,	0	,	     INCREMENTAL	,	1	,	  ALT_TEXT("white_lane_draw_card")	,	&WhiteLaneAnim	}	,
    
};

#define MAX_BUILDUP_STATE (sizeof(OpeningDef)/sizeof(Opening_Data))

#define NAVI_BUILDUP_IDX    (15)
#define AUDIO_BUILDUP_IDX   (16)
/***********************************
  Private Function Prototypes
***********************************/ 
void OpenScreenInit(void);
void OpeningRefresh(void);
void BuildUpAnimations(void);
void BottomBarLabelAnim(void);


/**************************************************************************************/
/*! \fn DisplayManagerInit(void)
*
*	\param - No parameters
*
*   \par Description:
*   This function creates the initial display.  Some display elements have an opening
*   animation.
*
*  \retval	None
*
*  \par Limitations/Caveats:
*	 None
*
**************************************************************************************/
void DisplayManagerInit(void)
{
    OpeningAnimComplete = 0;
    int32_t NavOpt = 0;
    int32_t AudioOpt = 0;
    uint8_t StepDuration = 0;
    //Hide all the commponents from  the build up animations
    //Build Up animations 
    HMI_AltiaSendEvent(ALT_TEXT("watermark_visible") ,0);		// turn off "Beta" text
//    HMI_AltiaSendEvent(ALT_TEXT("AudioFadeInAnim") ,0);
//    HMI_AltiaSendEvent(ALT_TEXT("NaviFadeInAnim"), 0);
    HMI_AltiaSendEvent(ALT_TEXT("white_lane_draw_card"), 0);
    HMI_AltiaSendEvent(ALT_TEXT("range_build_animation"), 0);
    HMI_AltiaSendEvent(ALT_TEXT("chg_build_animation"), 0);
    HMI_AltiaSendEvent(ALT_TEXT("eco_build_animation"), 0);
    HMI_AltiaSendEvent(ALT_TEXT("pwr_build_animation"), 0);
    HMI_AltiaSendEvent(ALT_TEXT("bottom_bar_build_animation"), 0);
    HMI_AltiaSendEvent(ALT_TEXT("eyebrows_reveal_animation"), 0);
    HMI_AltiaSendEvent(ALT_TEXT("speed_build_animation"),0);
    HMI_AltiaSendEvent(ALT_TEXT("drive_mode_build_animation"),0);

    //Shift the timer if the Nav audio is not present
    GET_ELEMENT(YzTdoNavOpts,&NavOpt);
    GET_ELEMENT(YzTdoAudioOpts,&AudioOpt);
    if(NavOpt != NAV_OPT_DISPLAY_EN)
    {
        StepDuration = OpeningDef[NAVI_BUILDUP_IDX].EndStep - OpeningDef[NAVI_BUILDUP_IDX].InitialStep;
        OpeningDef[MAX_BUILDUP_STATE-1].InitialStep -= StepDuration;
        OpeningDef[MAX_BUILDUP_STATE-1].EndStep -= StepDuration;
        //Update Audio timer
        OpeningDef[AUDIO_BUILDUP_IDX].InitialStep -= StepDuration;
        OpeningDef[AUDIO_BUILDUP_IDX].EndStep -= StepDuration;
    }
    if(AudioOpt != AUDIO_OPT_DISPLAY_EN)
    {
        StepDuration = OpeningDef[AUDIO_BUILDUP_IDX].EndStep - OpeningDef[AUDIO_BUILDUP_IDX].InitialStep;
        OpeningDef[MAX_BUILDUP_STATE-1].InitialStep -= StepDuration;
        OpeningDef[MAX_BUILDUP_STATE-1].EndStep -= StepDuration;
    }
    
    //Main animations
    HMI_AltiaSendEvent(ACC_ANIM_NAME, ACC_ANIM_DISABLE);
    HMI_AltiaSendEvent(DRIVE_MODE_SELECT_ANIM, DRIVE_MODE_SPORT);
    HMI_AltiaSendEvent(SPEED_LIMIT_INFO_ANIM, SPEED_LIMIT_INFO_DISABLE);
    HMI_AltiaSendEvent(DYNAMIC_POWER_BAR, 0);
    HMI_AltiaSendEvent(DYNAMIC_ECO_BAR, 0);
    HMI_AltiaSendEvent(DYNAMIC_CHG_BAR, 0);
    HMI_AltiaSendEvent(MILES_REMAIN_BAR_AIM,0);
    HMI_AltiaSendEvent(TURN_SIG_SELECT,TURN_SIG_DISABLE);
    HMI_AltiaSendEvent(TURN_WHITE_LANE_RIGHT_ENABLE,TURN_SIG_ENABLE);
    HMI_AltiaSendEvent(TURN_WHITE_LANE_LEFT_ENABLE,TURN_SIG_ENABLE);

    CONSOLE_OUT("Init HMI Display manager\n");
}


/**************************************************************************************/
/*! \fn DisplayManagerSetScreen(uint8_t Screen)
*
*   \param[in] Screen	- HMI screen state, defined in HMIControlSystemConstants.h.
*
*   \par Description:
*   This function draws the initial screen for each HMI operating state.
*
*   \retval	None
*
*   \par Limitations/Caveats:
*	 None
*
**************************************************************************************/
void DisplayManagerSetScreen(uint8_t Screen)
{
    switch(Screen)
    {
        case FF_LOGO_STATE:
        HMI_AltiaSendEvent(MODE_SCREEN_ANIM_NAME,MODE_SCREEN_FF_LOGO);
        OpenScreenInit();
        break;
        
        case FF_BUILDUP_STATE:
        HMI_AltiaSendEvent(MODE_SCREEN_ANIM_NAME,MODE_SCREEN_MAIN_SCREEN);
        CbInitSpeed_Link();
        break;
        
        case FF_MAIN_STATE:
        HMI_AltiaSendEvent(MODE_SCREEN_ANIM_NAME,MODE_SCREEN_MAIN_SCREEN);
        CbInitDynPower_Link();
        CbInitSpeed_Link();
        CbInitTurnSignal_Link();
		CbInitNav_Link();
		CbInitAudio_Link();
        break;
        
        case TEST_PATTERN_STATE:
        HMI_AltiaSendEvent(MODE_SCREEN_ANIM_NAME,MODE_SCREEN_TEST_PATTERN);
        CbInitTestPattern_Link();
        break;
    }
}


/**************************************************************************************/
/*! \fn DisplayManagerRefreshScreen(uint8_t Screen)
*
*   \param[in] Screen	- HMI screen state, defined in HMIControlSystemConstants.h.
*
*   \par Description:
*   This function refreshes the screen display every video frame for each HMI operating
*   screen state.
*
*   \retval	None
*
*   \par Limitations/Caveats:
*	 None
*
**************************************************************************************/
void DisplayManagerRefreshScreen(uint8_t Screen)
{
    static uint8_t Dummyvalue = 0;
    
    //Event so the pre-warp will be called every refresh cycle 
    HMI_AltiaSendEvent(ALT_TEXT("DummyEvent"), Dummyvalue);
    Dummyvalue ^= 1;
    
    switch(Screen)
    {
        case FF_LOGO_STATE:
        OpeningRefresh();
        break;
        
        case FF_BUILDUP_STATE:
        CbRefreshSpeed_Link(false);
        BuildUpAnimations();
        BottomBarLabelAnim();
        break;
        
                
        case FF_MAIN_STATE:
        //CbRefreshBattery_Link(false);
        CbRefreshTurnSignal_Link(false);
        CbRefreshSpeed_Link(false);
        CbRefreshDynPower_Link(false);
		CbRefreshNav_Link(false);
		CbRefreshAudio_Link(false);
        break;
        
        case TEST_PATTERN_STATE:
        CbRefreshTestPattern_Link(false);
        break;
    }
}

/**************************************************************************************/
/*! \fn OpenScreenInit(void)
*
*	\param - No parameters
*
*   \par Description:
*   This function performs the opening screen initialization.
*
*   \retval	None
*
*   \par Limitations/Caveats:
*	 None
*
**************************************************************************************/
void OpenScreenInit(void)
{
    OpeningState = OPENING_ANIM_INIT;
    OpeningAnimComplete = 0;
    HMI_AltiaSendEvent(OPENING_ANIM_NAME,OpeningState);     
}


 /**************************************************************************************/
/*! \fn OpeningRefresh(void)
 *
 *
 *  \par Description:
 *  This function update the FF logo animation step
 *
 *   \retval	None
 *
 *   \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
 void OpeningRefresh(void)
 {
     HMI_AltiaSendEvent(OPENING_ANIM_NAME,OpeningState);
     OpeningAnimComplete = (OpeningState == 0) ? 1:0;
     OpeningState--;
 }


 /**************************************************************************************/
/*! \fn BuildUpAnimations(void)
 *
 *
 *  \par Description:
 *  This funciton check if an animation from in the build up table need to be refreshed
 *  Update the animation step and if the Build up animation is complete set the flag
 *
 *   \retval	None
 *
 *   \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
 void BuildUpAnimations(void)
 {
     uint8_t i = 0;
     int32_t NavOpt = 0;
     int32_t AudioOpt = 0;
     int8_t CmpValue = 0; 
     GET_ELEMENT(YzTdoNavOpts,&NavOpt);
     GET_ELEMENT(YzTdoAudioOpts,&AudioOpt);
     
     for(i= 0; i< MAX_BUILDUP_STATE; i++)
     {
         if(animationstep>= OpeningDef[i].InitialStep && animationstep  <= OpeningDef[i].EndStep)
         {
             if(animationstep == OpeningDef[i].InitialStep) *OpeningDef[i].AltiaVar = OpeningDef[i].AltiaStepVar;
             
            //if Nav option is not enable never send the step
             if(memcmp ( OpeningDef[i].AltiaEvent, OpeningDef[NAVI_BUILDUP_IDX].AltiaEvent, sizeof(OpeningDef[NAVI_BUILDUP_IDX].AltiaEvent) ) == 0)
             {
                 if(NavOpt == NAV_OPT_DISPLAY_EN)
                 {
                     HMI_AltiaSendEvent(&OpeningDef[i].AltiaEvent, *OpeningDef[i].AltiaVar);
                 }
             }
             //if Audio option is not enable never send the step
             else if(memcmp ( OpeningDef[i].AltiaEvent, OpeningDef[AUDIO_BUILDUP_IDX].AltiaEvent, sizeof(OpeningDef[AUDIO_BUILDUP_IDX].AltiaEvent) ) == 0)
             {
                 if(AudioOpt == AUDIO_OPT_DISPLAY_EN)
                 {
                     HMI_AltiaSendEvent(&OpeningDef[i].AltiaEvent, *OpeningDef[i].AltiaVar);         
                 }
             }
             else
             {
                 HMI_AltiaSendEvent(&OpeningDef[i].AltiaEvent, *OpeningDef[i].AltiaVar); 
             }
             if(OpeningDef[i].Dir == INCREMENTAL)
             {
                 *OpeningDef[i].AltiaVar+= OpeningDef[i].step;
             }else 
             {
                 if(*OpeningDef[i].AltiaVar > 0) *OpeningDef[i].AltiaVar-=OpeningDef[i].step;
             }
         }
     }
     //if the animation step is bigger then the last end animation finish this state 
     if(animationstep > OpeningDef[MAX_BUILDUP_STATE-1].EndStep) BuildUpComplete = true;
     animationstep++;
 }

 /**************************************************************************************/
/*! \fn BottomBarLabelAnim(void)
 *
 *
 *  \par Description:
 *  This Function check the state of the dyamic power bar and set the color label
 *
 *   \retval	None
 *
 *   \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
void BottomBarLabelAnim(void)
{

    HMI_AltiaSendEvent(RANGE_UNIT_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
    
    if(ChgBarAnim > 0)
    {
        HMI_AltiaSendEvent(DYNAMIC_CHG_TXT_COLOR, DYNAMIC_MOTOR_TXT_WHITE);
        HMI_AltiaSendEvent(DYNAMIC_ECO_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
        HMI_AltiaSendEvent(DYNAMIC_POWER_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
    }else if(PwrBarAnim > 0)
    {
        HMI_AltiaSendEvent(DYNAMIC_CHG_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
        HMI_AltiaSendEvent(DYNAMIC_ECO_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
        HMI_AltiaSendEvent(DYNAMIC_POWER_TXT_COLOR, DYNAMIC_MOTOR_TXT_WHITE);
    }else if(EcoBarAnim > 0)
    {
        HMI_AltiaSendEvent(DYNAMIC_CHG_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
        HMI_AltiaSendEvent(DYNAMIC_ECO_TXT_COLOR, DYNAMIC_MOTOR_TXT_WHITE);
        HMI_AltiaSendEvent(DYNAMIC_POWER_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
    }else 
    {
        HMI_AltiaSendEvent(DYNAMIC_CHG_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
        HMI_AltiaSendEvent(DYNAMIC_ECO_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
        HMI_AltiaSendEvent(DYNAMIC_POWER_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
    }

}
 /*!
   @}  \todo
 */
 /* End of file */
