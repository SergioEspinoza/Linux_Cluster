/******************************************************************
 * hmi_utils.h
 *
 *  Description: 
 *   Created on: Jun 4, 2014
 *       Author: 10012885
 ******************************************************************/

#ifndef HMI_UTILS_H_
#define HMI_UTILS_H_

#ifndef HMI_UTILS_C_
#define HMI_UTILS_EXTERN extern
#else
#define HMI_UTILS_EXTERN
#endif 

/* Included Headers */
#include <stdint.h>

/* Public Function Prototypes */
HMI_UTILS_EXTERN int Integer_Str(int , char * , int ,int );
HMI_UTILS_EXTERN uint32_t SpeedConvertUnit(uint32_t SpeedValue, uint8_t Speedunit);

#endif /* HMI_UTILS_H_ */

/****************************************************************
 * History of Changes
 * --------------------------------------------------------------
 * Revision	Date		Author		Description
 * 0.1		06/05/2014	10012885	First Implementation.
 * 
 * 
 */
