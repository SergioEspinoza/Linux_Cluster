/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/**************************************************************************************/
/*!
 *    \file    	datainterface.h
 *
 *    \copyright Yazaki 2016
 *
 *    \brief 	
 *
 *    \author   Fernando V., D. Kageff
 *
 *  Modification history:
 *   $Log: datainterface.h  $
 *   Revision 1.5 2017/02/21 15:49:58CST Daniel Kageff (10011932) 
 *   Changes to work with redesigned datapool manager
 *   Revision 1.4 2016/11/28 12:11:57EST Fernando Villarreal Garza (10011234) 
 *   changes for Hmi 2 Version
 *   Revision 1.3 2016/11/18 11:58:00CST Fernando Villarreal Garza (10011234) 
 *   adjust for PCdemo
 *   Revision 1.2 2016/10/26 17:26:57CDT Fernando Villarreal Garza (10011234) 
 *   moved console_out for release version don't printf
 *   Revision 1.1 2016/10/12 18:53:55CDT Daniel Kageff (10011932) 
 *   Initial revision
 *   Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/HMILink/project.pj
 *
 */
/***************************************************************************************/

#ifndef DATAINTERFACE_H
#define DATAINTERFACE_H

/***********************************
		   INCLUDE FILES
***********************************/
#include "GraphicModelCfg.h"
#include "altia.h"

#ifdef PCDEMO
	#include "types.h"
	#include "Datapool.h"

#else
	#include <stdint.h>
	#include <stdbool.h>
	#include "pool_def.h"
	#include "Hmi_mgr_as.h"

#endif /*PCDEMO*/

/***********************************
	Public Macros and Typedefs
***********************************/

//TODO: add support for multiples types of data (32,64 string etc.)



/***********************************************************************************
*	CONSOLE PRINT 
************************************************************************************/
#ifdef USE_CONSOLE_OUT
	#include <time.h>
	#include <stdio.h>
#ifndef ONE_TIME_DECLARATION
#define ONE_TIME_DECLARATION
	time_t mytime;
#endif /*ONE_TIME_DECLARATION*/

//	#define CONSOLE_OUT(...)	printf(__VA_ARGS__)											/* do not print time */
//	#define CONSOLE_OUT(...)	mytime=time(0);printf(ctime(&mytime));printf(__VA_ARGS__)	/* Use actual date and time */
	#define CONSOLE_OUT(...)	printf(__VA_ARGS__)//mytime=time(0);printf("%ld, ",(int32_t)mytime);printf(__VA_ARGS__)			/* Use timestamp */
#else
	#define CONSOLE_OUT(...)	
#endif /*USE_CONSOLE_OUT*/


/***********************************************************************************
* PCDEMO/HW INTERFACE
************************************************************************************/
#ifdef PCDEMO
	#define HMI_AltiaSendEvent(eventName, eventValue)   altiaSendEvent((AltiaCharType*)eventName,eventValue)
	#define Hmi_AltiaSendText(eventName, eventValue)    altiaSendText((AltiaCharType*)eventName,eventValue)
	#define GET_ELEMENT(x, y)	DataPool_Get(x, (char *)y,DataPool_Length(x))		
	#define SET_ELEMENT(x, y)	DataPool_Set(x, (char *)y,DataPool_Length(x))	
#else
	#define HMI_AltiaSendEvent(eventName, eventValue)   altiaSendEvent((AltiaCharType*)eventName,eventValue)
	#define Hmi_AltiaSendText(eventName, eventValue)    altiaSendText((AltiaCharType*)eventName,eventValue)
	#define GET_ELEMENT(x, y)	GetElem(x, y)	
//	#define SET_ELEMENT(x, y)	//DataPool_Set(x, (char *)y,DataPool_Length(x))	
#endif /*PCDEMO*/


#endif /*DATAINTERFACE_H*/
