/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/*******************************************************************************************!
*  \addtogroup ...
*  @{
********************************************************************************************/

/**************************************************************************************/
/*!
 *  \file    Dis_Mgr.c
 *
 *  \brief    this is the link code bewteen Graphical model and datapool item
 *
 *  \author   Fernando V.
 *
 *  Modification history:
 *   $Log: Dis_Mgr.c  $
 *   Revision 1.5 2017/02/21 15:57:02CST Daniel Kageff (10011932) 
 *   Added #include files to fix compile error
 *   Revision 1.3 2016/11/23 12:05:55EST Fernando Villarreal Garza (10011234) 
 *   changes for V2 HMI version
 *   Revision 1.2 2016/10/21 18:02:10EDT Fernando Villarreal Garza (10011234) 
 *   added test pattern handler
 *   Revision 1.1 2016/10/06 13:54:46CDT Daniel Kageff (10011932) 
 *   Initial revision
 *   Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/App/project.pj
 *
 *
 ***************************************************************************************/

 /***********************************
       INCLUDE FILES
***********************************/
#include <INTEGRITY.h>

#include "gp_cfg.h"			// Common GP program configuration settings
#include "gp_types.h"		// Common GP program data type definitions

#include "Dis_Mgr.h"
#include "Dis_GearPosition.h"
#include "Dis_TestPattern.h"
#include "datainterface.h"
#include "Dis_Common.h"
/***********************************
  Private Macros and Typedefs
***********************************/

/***********************************
  Private Data and Structures
**********************************/

/***********************************
  Private Function Prototypes
***********************************/ 
static const APPState * stg_DisMgr_TBL[] =
{
    //&Dis_GearPosition,
    &Dis_TestPattern
};

#define NUM_DISPLAYS (sizeof(stg_DisMgr_TBL)/sizeof(APPState*))


/**************************************************************************************/
/*! \fn u1g_Dis_Init
*
*
*  \par Description:
*  This function initlize all variables of the Battery icon status 
*
**************************************************************************************/
void u1g_Dis_Init(void)
{
    uint8_t u1t_Index;

    for ( u1t_Index = 0u; u1t_Index < NUM_DISPLAYS; u1t_Index++ )
    {
        stg_DisMgr_TBL[ u1t_Index ] ->Init();
    }
    return;
}

/**************************************************************************************/
/*! \fn u1g_Dis_Task
*
*
*  \par Description:
*  This function initlize all variables of the Battery icon status 
*
**************************************************************************************/
void u1g_Dis_Task(void)
{
    uint8_t u1t_Index;

    for ( u1t_Index = 0u; u1t_Index < NUM_DISPLAYS; u1t_Index++ )
    {
        stg_DisMgr_TBL[ u1t_Index ] ->Periodic();
    }
    return;
}

/*!
  @}  \todo
*/
/* End of file */
