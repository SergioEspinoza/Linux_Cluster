/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/*******************************************************************************************!
*  \addtogroup ...
*  @{
********************************************************************************************/

/**************************************************************************************/
/*!
 *  \file    SpeedLink.c
 *
 *  \brief    this is the link code bewteen Graphical model and datapool item
 *
 *  \author   Fernando V.
 *
 *  Modification history:
 *   $Log: SpeedLink.c  $
 *   Revision 1.5 2016/12/07 17:45:07CST Daniel Kageff (10011932) 
 *   Removed PRNDL check for vehicle speed display update
 *   Revision 1.4 2016/12/05 17:20:31EST Daniel Kageff (10011932) 
 *   Changes to use signed integers for the datapool items and to use common datapool management/access functions between the GP app and HMI
 *   Revision 1.3 2016/11/02 21:06:34EDT Fernando Villarreal Garza (10011234) 
 *   N state display speed
 *   Revision 1.2 2016/10/27 09:05:23CDT Daniel Kageff (10011932) 
 *   Corrected a warning
 *   Revision 1.1 2016/10/07 12:35:00EDT Daniel Kageff (10011932) 
 *   Initial revision
 *   Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/HMILink/project.pj
 *
 *
 ***************************************************************************************/
#define SPEEDLINK_C
  
/***********************************
        INCLUDE FILES
***********************************/
#include "SpeedLink.h"
#include "GraphicModelCfg.h"
#include "datainterface.h"
#include "Dis_GearPosition.h"
#include <wchar.h>
#include <stdio.h>
#include <stdlib.h>

#include <hmi_utils.h>
 /***********************************
   Private Macros and Typedefs
 ***********************************/
 /*! \brief ...... */
#define REFRESH_FREQ		(1)	/* Data refresh frequency threshold */

#define SPEED_MAX_VALUE     (200)
#define SPEED_ERROR_VALUE   (0xFFFFFFFFF)
#define SPEED_DASHES        API_TEXT("----")

 /***********************************
   Private Data and Structures
 **********************************/
 static uint8_t	RefreshCounter;
 
 /***********************************
   Private Function Prototypes
 ***********************************/ 
 
 /**************************************************************************************/
 /*! \fn DisplayManagerInit
 *
 *
 *  \par Description:
 *  This function initlize all variables of the Battery icon status 
 *
 **************************************************************************************/
 void CbInitSpeed_Link(void)
 {
     RefreshCounter = 0;
     CbRefreshSpeed_Link(true);
 }
 
 /**************************************************************************************/
 /*! \fn CbRefreshBattery_Link
 *
 *
 *  \par Description:
 *  This Function do the refresh status of the Battery icon and the bar 
 *
 **************************************************************************************/
 void CbRefreshSpeed_Link(uint8_t forceupdate)
 {	
     int32_t    SpeedValue = 0;
     uint8_t    SpeedFractional = 0;
     AltiaCharType    SpeedText[100];
     char    tmp[100];
     
     if (forceupdate == true)
     {
         RefreshCounter = REFRESH_FREQ; 	//Force the counter's timeout
     }
     else
     {
         RefreshCounter++;				//Count this cycle
     }
 
     if(RefreshCounter >= REFRESH_FREQ)
     {
         GET_ELEMENT(YzTdSpeedValue,&SpeedValue);
         
         //process Speed value 
         SpeedValue = SpeedConvertUnit(SpeedValue,1);
         SpeedFractional = SpeedValue % 100;

         SpeedValue/=100;
         if(SpeedFractional > 0) SpeedValue++;

		 /* If the speed value is valid then update the display with it */
         if(SpeedValue != SPEED_ERROR_VALUE)
         {
//             int32_t PrndState = 0;
//             GET_ELEMENT(YzTdPRNDL,&PrndState);					DK - DISABLE PRNDL CHECK FOR SPEED
//             if(PrndState == GearPosition_P) SpeedValue = 0;
                
             if(SpeedValue > SPEED_MAX_VALUE) SpeedValue = SPEED_MAX_VALUE;
             sprintf(tmp, "%d", SpeedValue);
             mbstowcs (SpeedText, tmp, 100);
             Hmi_AltiaSendText(SPEED_VALUE_ANIM_NAME,SpeedText);
            
         }
		 /* Else speed value is invalid then display speed error indicator */
         else
         {
             Hmi_AltiaSendText(SPEED_VALUE_ANIM_NAME,SPEED_DASHES);
         }
     }
 }
 
 /*!
   @}  \todo
 */
 /* End of file */
