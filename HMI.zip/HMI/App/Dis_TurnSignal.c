/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/**************************************************************************************/
/*!
 *  \file    Dis_TurnSignal.c
 *
 *  \brief    This module is a gateway between CAN and SPI messages to the GP 
 *
 *  \author    Fernando V.
 *
 *  Modification history:
 *   $Log: Dis_TurnSignal.c  $
 *   Revision 1.1 2016/08/24 09:52:30CDT Daniel Kageff (10011932) 
 *   Initial revision
 *   Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/App/project.pj
 *
 *
 ***************************************************************************************/
 
 #define DIS_TURNSIGNAL_C
 
 /***********************************
        INCLUDE FILES
 ***********************************/
 #include "types.h"
 #include "Dis_TurnSignal.h"
 #include "datainterface.h"
 /***********************************
   Private Macros and Typedefs
 ***********************************/
 
 /***********************************
   Private Data and Structures
 ***********************************/
 
 /***********************************
   Private Function Prototypes
 ***********************************/
 
 
/**************************************************************************************/
/*! \fn GearPosition_StartupInit ( void )
*
*
*  \par Description:
*  This function is called at the startup of the HMI and initialize the state of the Gear state
*
**************************************************************************************/
  
void TurnSignal_StartupInit(void)
{
 
}
 
/**************************************************************************************/
/*! \fn GearPosition_PeriodicTask ( void )
*
*
*  \par Description:
*  This function read the Gear state and  trigger an event to the state machine
*
**************************************************************************************/
  
void TurnSignal_PeriodicTask(void)
{
    uint8_t TurnLeftSignalSate = 0;
    uint8_t TurnRightSignalSate = 0;
    //GET_ELEMENT(YzTdTurnLeftSig,&TurnLeftSignalSate);
    //GET_ELEMENT(YzTdTurnRightSig,&TurnRightSignalSate);
    
    if(TurnLeftSignalSate == TurnSig_ON || TurnRightSignalSate == TurnSig_ON)
    {
        //HMISS_PostHMIEvent(TURN_SIGNAL_EVENT);    
    }
    
}

