#ifndef _visualSTATE_HMICONTROLSYSTEMACTION_H
#define _visualSTATE_HMICONTROLSYSTEMACTION_H

/*
 * Id:        HMIControlSystemAction.h
 *
 * Function:  VS System Action Expression Pointer Table Header File.
 *
 * This is an automatically generated file. It will be overwritten by the Coder.
 * 
 * DO NOT EDIT THE FILE!
 */


#include "HMIControlSystemSEMBDef.h"


#if (VS_CODER_GUID != 0X00bffeeecL)
#error The generated file does not match the SEMTypes.h header file.
#endif


/*
 * Action Function Prototypes.
 */
extern void DisplayManagerGearEvent (int Trans);
extern void DisplayManagerInit (void);
extern void DisplayManagerRefreshParkMode (void);
extern void DisplayManagerRefreshScreen (int Screen);
extern void DisplayManagerSetScreen (uint8_t Screen);


/*
 * Action Expression Function Prototypes.
 */
extern void System1VSAction_2 (void);

extern void System1VSAction_3 (void);

extern void System1VSAction_4 (void);

extern void System1VSAction_5 (void);

extern void System1VSAction_6 (void);

extern void System1VSAction_7 (void);

extern void System1VSAction_8 (void);

extern void System1VSAction_9 (void);


/*
 * Action Expression Pointer Table.
 */
extern VS_ACTIONEXPR_TYPE const System1VSAction[10];


#endif /* ifndef _visualSTATE_HMICONTROLSYSTEMACTION_H */
