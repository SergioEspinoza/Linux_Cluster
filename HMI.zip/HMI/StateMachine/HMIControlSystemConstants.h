#ifndef _visualSTATE_HMICONTROLSYSTEMCONSTANTS_H
#define _visualSTATE_HMICONTROLSYSTEMCONSTANTS_H

/*
 * Id:        HMIControlSystemConstants.h
 *
 * Function:  Constants.
 *
 * This is an automatically generated file. It will be overwritten by the Coder.
 * 
 * DO NOT EDIT THE FILE!
 */


/*
 * Constants.
 */
#define FF_BUILDUP_STATE                 ((int) 4)
#define FF_LOGO_STATE                    ((int) 1)
#define FF_MAIN_STATE                    ((int) 2)
#define TEST_PATTERN_STATE               ((int) 3)


#endif /* ifndef _visualSTATE_HMICONTROLSYSTEMCONSTANTS_H */
