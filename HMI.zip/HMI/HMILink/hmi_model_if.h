/*******************************************************************************
*  $Log: hmi_model_if.h  $
*  Revision 1.1 2015/03/31 17:09:20CST Daniel Kageff (10011932) 
*  Initial revision
*  Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/HMILink/project.pj
*  Revision 1.3 2014/06/03 12:39:25CDT Edgar Rios Lucas (10032297) 
*  Releasing HMI 1.0
*  Release notes and change analysis pending
*  Revision 1.2 2014/06/02 08:29:37CDT Kevin Russo (kevinadm) 
*  Member moved from hmi_model_if.h in project /Projects/Hyundai/2016_KiaQLIPC/Software Development/Eng/Application/Include/project.pj to hmi_model_if.h in project /Projects/Hyundai/2016_KiaQLIPC/Software Development/Eng/HMI/Link/project.pj.
*  Revision 1.1 2014/04/17 13:10:15EDT Gregory Palarski (10030324) 
*  Initial revision
*  Member added to project /Projects/Hyundai/2016_KiaQLIPC/Software Development/Eng/Application/Include/project.pj
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/********************************************************************************************
*  File:  hmi_model_if.h 
*
*  Description: This is the public interface for HMI model interface.
********************************************************************************************/
#ifndef HMI_MODEL_IF_H   
#define HMI_MODEL_IF_H   

/*******************************************************************************************/
/*    I N C L U D E   F I L E S                                                            */
/*******************************************************************************************/
#include "hmi_ss_cfg.h"

/*******************************************************************************************/
/*    M A C R O S                                                                          */
/*******************************************************************************************/


/*******************************************************************************************/
/*    T Y P E S   A N D   E N U M E R A T I O N S                                          */
/*******************************************************************************************/


/*******************************************************************************************/
/*    F U N C T I O N   P R O T O T Y P E S                                                */
/*******************************************************************************************/



#endif
/* End of file */
