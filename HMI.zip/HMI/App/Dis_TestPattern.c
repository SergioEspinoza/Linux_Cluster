/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/**************************************************************************************/
/*!
 *  \file    Dis_TestPattern.c
 *
 *  \brief    This module is a gateway between CAN and SPI messages to the GP 
 *
 *  \author    Fernando V.
 *
 *  Modification history:
 *   $Log: Dis_TestPattern.c  $
 *   Revision 1.2 2016/12/05 16:25:47CST Daniel Kageff (10011932) 
 *   Changes to use signed integers for the datapool items and to use common datapool management/access functions between the GP app and HMI
 *   Revision 1.1 2016/10/10 15:32:40EDT Daniel Kageff (10011932) 
 *   Initial revision
 *   Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/App/project.pj
 *
 *
 ***************************************************************************************/
 
 #define DIS_TESTPATTERN_C
 
 /***********************************
        INCLUDE FILES
 ***********************************/
 #include "Dis_TestPattern.h"
 #include "datainterface.h"
 #include "hmi_priv.h"
 /***********************************
   Private Macros and Typedefs
 ***********************************/
 
 /***********************************
   Private Data and Structures
 ***********************************/
 const APPState Dis_TestPattern =
 {
 	TestPattern_StartupInit,
 	TestPattern_PeriodicTask,
 };

 /***********************************
   Private Function Prototypes
 ***********************************/
 
 
/**************************************************************************************/
/*! \fn TestPattern_StartupInit ( void )
*
*
*  \par Description:
*  This function is called at the startup of the HMI and initialize the state of the Gear state
*
**************************************************************************************/
  
void TestPattern_StartupInit(void)
{

}
 
/**************************************************************************************/
/*! \fn TestPattern_PeriodicTask ( void )
*
*
*  \par Description:
*  This function read the Gear state and  trigger an event to the state machine
*
**************************************************************************************/
  
void TestPattern_PeriodicTask(void)
{
    int32_t TestPatternValue = 0;
    GET_ELEMENT(YzTdTestPattern,&TestPatternValue);
    if(TestPatternValue > 0)
    {
        HMISS_PostHMIEvent(TEST_PATTERN_EVENT);   
    }
}
