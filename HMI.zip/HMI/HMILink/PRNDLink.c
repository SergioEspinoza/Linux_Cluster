/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/*******************************************************************************************!
*  \addtogroup ...
*  @{
********************************************************************************************/

/**************************************************************************************/
/*!
 *  \file    batteryLink.c
 *
 *  \brief    this is the link code bewteen Graphical model and datapool item
 *
 *  \author   Fernando V.
 *
 *  Modification history:
 *   $Log: PRNDLink.c  $
 *   Revision 1.2 2016/12/05 16:23:22CST Daniel Kageff (10011932) 
 *   Changes to use signed integers for the datapool items and to use common datapool management/access functions between the GP app and HMI
 *   Revision 1.1 2016/10/05 16:26:30EDT Daniel Kageff (10011932) 
 *   Initial revision
 *   Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/HMILink/project.pj
 *
 *
 ***************************************************************************************/
  #define PRNDLINK_C
  
  /***********************************
        INCLUDE FILES
 ***********************************/
 #include "PRNDLink.h"
 #include "GraphicModelCfg.h"
 #include "datainterface.h"
 
 /***********************************
   Private Macros and Typedefs
 ***********************************/
 /*! \brief ...... */
#define REFRESH_FREQ		(1)	/* Data refresh frequency threshold */

 /***********************************
   Private Data and Structures
 **********************************/
 static uint8_t	RefreshCounter;
 
 /***********************************
   Private Function Prototypes
 ***********************************/ 
 
 /**************************************************************************************/
 /*! \fn DisplayManagerInit
 *
 *
 *  \par Description:
 *  This function initlize all variables of the Battery icon status 
 *
 **************************************************************************************/
 void CbInitPRND_Link(void)
 {
     RefreshCounter = 0;
     CbRefreshPRND_Link(true);
 }
 
 /**************************************************************************************/
 /*! \fn CbRefreshBattery_Link
 *
 *
 *  \par Description:
 *  This Function do the refresh status of the Battery icon and the bar 
 *
 **************************************************************************************/
 void CbRefreshPRND_Link(uint8_t forceupdate)
 {	
     int32_t    PrndState = 0;

     if (forceupdate == true)
     {
         RefreshCounter = REFRESH_FREQ; 	//Force the counter's timeout
     }else
     {
         RefreshCounter++;				//Count this cycle
     }
 
     if(RefreshCounter >= REFRESH_FREQ)
     {
         GET_ELEMENT(YzTdPRNDL,&PrndState);
         if(PrndState > PRNDL_VALUE_MAX) PrndState = PRNDL_VALUE_MAX;
         HMI_AltiaSendEvent(PRNDL_VALUE_ANIM_NAME,PrndState);
     }
 }
 
 /*!
   @}  \todo
 */
 /* End of file */
