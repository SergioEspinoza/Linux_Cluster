/*******************************************************************************
*
*                           (c) Copyright 2012
*                           Yazaki North America
*                           All Rights Reserved
*  ----------------------------------------------------------------------------
*
*   Unpublished, Yazaki North America Inc. All rights reserved. 
*  This document is protected by the copyright law of the United States and 
*  foreign countries.  The work embodied in this document is confidential and 
*  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
*  this document and any use or disclosure of this document or the work 
*  embodied in it without the written authority of Yazaki North America, Inc., 
*  will constitute copyright and trade secret infringement and will violate the
*  rights of Yazaki North America, Inc.
*
*******************************************************************************/
/*******************************************************************************************!
*  \addtogroup ...
*  @{
********************************************************************************************/

/**************************************************************************************/
/*!
 *  \file    DistRangeLink.c
 *
 *  \brief    this is the link code bewteen Graphical model and datapool item
 *
 *  \author   Fernando V.
 *
 *  Modification history:
 *   $Log: DistRangeLink.c  $
 *   Revision 1.1 2016/10/05 15:26:36CDT Daniel Kageff (10011932) 
 *   Initial revision
 *   Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/HMILink/project.pj
 *
 *
 ***************************************************************************************/
  #define BATTERYLINK_C
  
  /***********************************
        INCLUDE FILES
 ***********************************/
 #include "DistRangeLink.h"
 #include "GraphicModelCfg.h"
 #include "datainterface.h"
 
 /***********************************
   Private Macros and Typedefs
 ***********************************/
 /*! \brief ...... */
#define REFRESH_FREQ		(1)	/* Data refresh frequency threshold */

 /***********************************
   Private Data and Structures
 **********************************/
 static uint8_t	RefreshCounter;
 
 /***********************************
   Private Function Prototypes
 ***********************************/ 
 
 /**************************************************************************************/
 /*! \fn CbInitDistRange_Link
 *
 *
 *  \par Description:
 *  This function initlize all variables of the Battery icon status 
 *
 **************************************************************************************/
 void CbInitDistRange_Link(void)
 {
     RefreshCounter = 0;
     CbRefreshDistRange_Link(true);
 }
 
 /**************************************************************************************/
 /*! \fn CbRefreshDistRange_Link
 *
 *
 *  \par Description:
 *  This Function do the refresh status of the Battery icon and the bar 
 *
 **************************************************************************************/
 void CbRefreshDistRange_Link(uint8_t forceupdate)
 {	
     uint32_t    DistRangeValue = 0;

     if (forceupdate == true)
     {
         RefreshCounter = REFRESH_FREQ; 	//Force the counter's timeout
     }else
     {
         RefreshCounter++;				//Count this cycle
     }
 
     if(RefreshCounter >= REFRESH_FREQ)
     {
         
         // \TODO: GET_ELEMENT(...,&DistRangeValue);
         //Conversion unit
         //Display data
         // Send data to be stored in the NVM
     }
 }
 
 /*!
   @}  \todo
 */
 /* End of file */
