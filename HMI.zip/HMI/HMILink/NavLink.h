/**************************************************************************************/
/*!
 *  \file    NavLink.h
 *
 *  \brief    This is the public interface for the link code bewteen Graphical model  
 *			  and navigation datapool items.
 *
 *  \author   D. Kageff
 *
 *  \copyright (c) Copyright 2016, Yazaki North America
 *                           All Rights Reserved
 *
 *   Unpublished, Yazaki North America Inc. All rights reserved. 
 *  This document is protected by the copyright law of the United States and 
 *  foreign countries.  The work embodied in this document is confidential and 
 *  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
 *  this document and any use or disclosure of this document or the work 
 *  embodied in it without the written authority of Yazaki North America, Inc., 
 *  will constitute copyright and trade secret infringement and will violate the
 *  rights of Yazaki North America, Inc.
 *
 *  Modification history:
 *  \version $Log: NavLink.h  $
 *  \version Revision 1.1 2016/12/12 12:15:01CST Daniel Kageff (10011932) 
 *  \version Initial revision
 *  \version Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/HMILink/project.pj
 *
 *
 ***************************************************************************************/
#ifndef NAVLINK_H
#define NAVLINK_H

/***********************************
      INCLUDE FILES
***********************************/
#include "datainterface.h"

/***********************************
  Public Macros and Typedefs
***********************************/
/*! Navigation display control options */
typedef enum {
	NAV_OPT_DISPLAY_EN	= 0x00000001,			/*!< Enable navigation display if this bit is set */
} NAV_OPTIONS_T;

/***********************************
   Public Function Prototypes
***********************************/ 

/**************************************************************************************/
/* Function: CbInitNav_Link
*
*  Description:
*  This function initializes the navigation display datapool linkage functions. 
*
**************************************************************************************/
void CbInitNav_Link(void);

/**************************************************************************************/
/*! Function: CbRefreshNav_Link
*
*  Description:
*  This function updates the navigation HMI display item. 
*
**************************************************************************************/
void CbRefreshNav_Link(uint8_t forceupdate);


#endif		// End NAVLINK_H
