/**************************************************************************************/
/*!
 *  \file    DynPowerLink.c
 *
 *  \brief    This is the link code bewteen Graphical model and dynamic power datapool 
 *			  items.
 *
 *  \author   D. Kageff
 *
 *  \copyright (c) Copyright 2016, Yazaki North America
 *                           All Rights Reserved
 *
 *   Unpublished, Yazaki North America Inc. All rights reserved. 
 *  This document is protected by the copyright law of the United States and 
 *  foreign countries.  The work embodied in this document is confidential and 
 *  constitutes a trade secret of Yazaki North America, Inc.  Any copying of 
 *  this document and any use or disclosure of this document or the work 
 *  embodied in it without the written authority of Yazaki North America, Inc., 
 *  will constitute copyright and trade secret infringement and will violate the
 *  rights of Yazaki North America, Inc.
 *
 *  Modification history:
 *  \version $Log: DynPowerLink.c  $
 *  \version Revision 1.3 2016/12/08 11:40:20CST Fernando Villarreal Garza (10011234) 
 *  \version added labels control
 *  \version Revision 1.2 2016/12/06 17:34:03CST Daniel Kageff (10011932) 
 *  \version Initial working revision
 *  \version Revision 1.1 2016/12/06 10:48:40EST Daniel Kageff (10011932) 
 *  \version Initial revision
 *  \version Member added to project /Projects/Faraday Future/2018_FFHUD/Software Development/Eng/GP/HMI/HMILink/project.pj
 *
 *
 ***************************************************************************************/
#define DYNPOWERLINK_C
  
/***********************************
        INCLUDE FILES
***********************************/
#include "GraphicModelCfg.h"
#include "datainterface.h"
#include "Dis_GearPosition.h"
#include <wchar.h>
#include <stdio.h>
#include <stdlib.h>

#include <hmi_utils.h>

#include "DynPowerLink.h"

 /***********************************
   Private Macros and Typedefs
 ***********************************/
 /*! Refresh frequency control */
#define DYN_REFRESH_FREQ (5)		/*!< Data refresh period in video frame time units (currently 17 msec) */

#define DYN_PWR_FACTOR (float)9548.8 		/*!< Dynamic power calc factor, in kW. */
#define MAX_POS_DYN_PWR 600.0				/*!< Maximum positive dynamic power out, in kW. */
#define MAX_NEG_DYN_PWR 125.0				/*!< Maximum positive dynamic regen power, in kW. */

#define ECO_PWR_THRESHOLD 75.0				/*!< kW threshold to transition from ECO to PWR bar */

/*! PWR range percentage calculation factor */
#define PWR_PCT_CONV (float)((float)DYNAMIC_POWER_BAR_MAX / (MAX_POS_DYN_PWR - ECO_PWR_THRESHOLD))

/*! ECO range percentage calculation factor */
#define ECO_PCT_CONV (float)((float)DYNAMIC_ECO_BAR_MAX / ECO_PWR_THRESHOLD)

/*! CHG range percentage calculation factor */
#define CHG_PCT_CONV (float)((float)DYNAMIC_CHG_BAR_MAX / MAX_NEG_DYN_PWR)

 /***********************************
   Private Data and Structures
 **********************************/
static int	RefreshCounter;
 
 /***********************************
   Private Function Prototypes
 ***********************************/ 
 

/************ Start of code ******************/

/**************************************************************************************/
/*! \fn CbInitDynPower_Link()
 *
 *	param - No parameters
 *
 *  \par Description:	  
 *   This function initializes the dynamic power datapool linkage functions.  
 *
 *  \retval	None
 *
 *  \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
void CbInitDynPower_Link(void)
{
	RefreshCounter = 0;
	CbRefreshDynPower_Link(true);		// Initial display of dynamic power bar
}



/**************************************************************************************/
/*! \fn CbRefreshDynPower_Link(uint8_t forceupdate)
 *
 *	param[in] forceupdate	- If non-0, then force the display to update even if the 
 *							  data hasn't changed.
 *
 *  \par Description:	  
 *   This function updates the dynamic power HMI display item.  
 *
 *  \retval	None
 *
 *  \par Limitations/Caveats:
 *	 None
 *
 **************************************************************************************/
void CbRefreshDynPower_Link(uint8_t forceupdate)
{	
	int32_t	speedMotorFront;		// motor speed in RPM
	int32_t	speedMotorRL;
	int32_t	speedMotorRR;
	int32_t torqueActualFront;		// motor torque in N-m
	int32_t torqueActualRL;
	int32_t torqueActualRR;

	if (forceupdate == true)
	{
		RefreshCounter = DYN_REFRESH_FREQ; 	//Force the counter's timeout
	}
	else
	{
		RefreshCounter++;				//Count this cycle
	}

	if(RefreshCounter >= DYN_REFRESH_FREQ)
	{
		float dyn_power;
		int dyn_eco_pct;			// Used for ECO bar percent
		int dyn_pwr_pct;			// Used for CHG and PWR bar percent
		int dyn_chg_pct;			// Used for CHG bar percent

		/* Get the data for the calculation */
		GET_ELEMENT(YzTdoSpeedMotorFront,&speedMotorFront);
		GET_ELEMENT(YzTdoSpeedMotorRL,&speedMotorRL);
		GET_ELEMENT(YzTdoSpeedMotorRR,&speedMotorRR);
		GET_ELEMENT(YzTdoTorqueActualFront,&torqueActualFront);
		GET_ELEMENT(YzTdoTorqueActualRL,&torqueActualRL);
		GET_ELEMENT(YzTdoTorqueActualRR,&torqueActualRR);

		/* Calculate the dynamic power.  The equation is:
		   Motor Power/Regenerative Power = ( (torqueActualFront_PTC * speedMotorFront_PTC)
		    + (torqueActualRL_PTC * speedMotorRL_PTC) + (torqueActualRR_PTC * speedMotorRR_PTC) ) / 9548.8 (in kW) */
		dyn_power = (  ((float)torqueActualFront * (float)speedMotorFront)
					 + ((float)torqueActualRL * (float)speedMotorRL)
					 + ((float)torqueActualRR * (float)speedMotorRR)) / DYN_PWR_FACTOR;
		/* Convert to percentage */
		if(dyn_power >= (float)0.0)		// ECO/PWR power bars
		{
			/* Power is in the ECO range */
			if(dyn_power < ECO_PWR_THRESHOLD)
			{
				dyn_eco_pct = (int)((dyn_power * ECO_PCT_CONV) + 0.5);	// convert to bar percent
				dyn_pwr_pct = 0;
			}
			/* Power is in the PWR range */
			else if(dyn_power < MAX_POS_DYN_PWR)
			{
				dyn_eco_pct = DYNAMIC_ECO_BAR_MAX - 1;
				dyn_pwr_pct = (int)((dyn_power * PWR_PCT_CONV) + 0.5);	// convert to bar percent
			}
			else		// Power is max'd out
			{
				dyn_eco_pct = DYNAMIC_ECO_BAR_MAX - 1;
				dyn_pwr_pct = DYNAMIC_POWER_BAR_MAX - 1;
			}
			dyn_chg_pct = 0;
		}
		/* Else power is in the CHG (regenerative) power range */
		else		// CHG (regen) power bar
		{
			float temp = abs(dyn_power);
			dyn_eco_pct = 0;
			dyn_pwr_pct = 0;

			if(temp < MAX_NEG_DYN_PWR)
			{
				dyn_chg_pct = (int)((temp * CHG_PCT_CONV) + 0.5);	// convert to bar percent
			}
			else
			{
				dyn_chg_pct = DYNAMIC_ECO_BAR_MAX - 1;
			}
		}

		/* Update the display */
		HMI_AltiaSendEvent(DYNAMIC_ECO_BAR, dyn_eco_pct);
		HMI_AltiaSendEvent(DYNAMIC_POWER_BAR, dyn_pwr_pct);
		HMI_AltiaSendEvent(DYNAMIC_CHG_BAR, dyn_chg_pct);
        // Update the txt label color 
        if(dyn_chg_pct > 0)
        {
            HMI_AltiaSendEvent(DYNAMIC_CHG_TXT_COLOR, DYNAMIC_MOTOR_TXT_WHITE);
            HMI_AltiaSendEvent(DYNAMIC_ECO_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
            HMI_AltiaSendEvent(DYNAMIC_POWER_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
        }else if(dyn_pwr_pct > 0)
        {
            HMI_AltiaSendEvent(DYNAMIC_CHG_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
            HMI_AltiaSendEvent(DYNAMIC_ECO_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
            HMI_AltiaSendEvent(DYNAMIC_POWER_TXT_COLOR, DYNAMIC_MOTOR_TXT_WHITE);
        }else if(dyn_eco_pct > 0)
        {
            HMI_AltiaSendEvent(DYNAMIC_CHG_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
            HMI_AltiaSendEvent(DYNAMIC_ECO_TXT_COLOR, DYNAMIC_MOTOR_TXT_WHITE);
            HMI_AltiaSendEvent(DYNAMIC_POWER_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
        }else 
        {
            HMI_AltiaSendEvent(DYNAMIC_CHG_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
            HMI_AltiaSendEvent(DYNAMIC_ECO_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
            HMI_AltiaSendEvent(DYNAMIC_POWER_TXT_COLOR, DYNAMIC_MOTOR_TXT_GRAY);
        }
		/* Reset refresh counter */
		RefreshCounter = 0;
	}
}
