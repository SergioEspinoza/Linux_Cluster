#ifndef _visualSTATE_HMICONTROLSYSTEM_H
#define _visualSTATE_HMICONTROLSYSTEM_H

/*
 * Id:        HMIControlSystem.h
 *
 * Function:  VS System Header File.
 *
 * This is an automatically generated file. It will be overwritten by the Coder.
 * 
 * DO NOT EDIT THE FILE!
 */


#include "HMIControlSystemSEMBDef.h"


#if (VS_CODER_GUID != 0X00bffeeecL)
#error The generated file does not match the SEMTypes.h header file.
#endif


#endif /* ifndef _visualSTATE_HMICONTROLSYSTEM_H */
