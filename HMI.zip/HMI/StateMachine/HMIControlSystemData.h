#ifndef _visualSTATE_HMICONTROLSYSTEMDATA_H
#define _visualSTATE_HMICONTROLSYSTEMDATA_H

/*
 * Id:        HMIControlSystemData.h
 *
 * Function:  VS System Data Header File.
 *
 * This is an automatically generated file. It will be overwritten by the Coder.
 * 
 * DO NOT EDIT THE FILE!
 */


#include "HMIControlSystemSEMBDef.h"


#if (VS_CODER_GUID != 0X00bffeeecL)
#error The generated file does not match the SEMTypes.h header file.
#endif


/*
 * Event Identifier Definitions.
 */
#define SE_RESET                         0X000u  /*   0 */
#define Tmr_Task                         0X001u  /*   1 */
#define TestPattern                      0X002u  /*   2 */


/*
 * VS System External Variable Declarations.
 */
extern int BuildUpComplete;

extern int OpeningAnimComplete;


#endif /* ifndef _visualSTATE_HMICONTROLSYSTEMDATA_H */
